# PromptForge Pro

A professional AI prompt processing and management tool for documentary content creators built with Flutter.

## Features

### Editor Mode
- **Import & Parse**: Multiple prompt parsing formats (blank-line separated, numbered, lettered, scene tags)
- **Bulk Editing**: Reorderable prompts with drag-and-drop support
- **Bulk Selection**: Select, deselect, and batch-delete prompts
- **Scene Manager**: Strip numbers and re-index scenes with format options
- **Export**: Share prompts in multiple formats (Plain Text, Numbered, JSON)

### Pipeline Mode
A sophisticated multi-step processing pipeline with real-time feedback:

1. **Input Payload** - Accept and clean raw prompt text
2. **Scene Splitter** - Automatically split content into scenes by word count
3. **Environment Variables** - Define and inject dynamic variables ({{VAR}})
4. **Global Find & Replace** - Batch text transformations
5. **Style Injection** - Apply AI art style presets to all prompts
6. **Prefix & Suffix** - Add wrapping text (e.g., "/imagine prompt:" and "--v 6.0")
7. **Scene Indexing** - Auto-number scenes in multiple formats
8. **Slice & Range** - Select specific scene ranges for processing
9. **Compiled Output** - View final, env-applied, and style-applied versions
10. **Batch Export** - Split output into manageable chunks
11. **History** - Restore previous pipeline configurations
12. **Telemetry** - Real-time processing statistics and validation logs

## Theme

**Noir Cinematic** - Professional noir investigative aesthetic
- Background: `#0a0a0a`
- Surface: `#111111`
- Primary Accent (Crimson): `#c0392b`
- Secondary Accent (Gold): `#d4a017`
- Typography: Inter (UI) + JetBrains Mono (code)

## Architecture

### Project Structure
```
lib/
├── main.dart                 # App entry point & navigation
├── theme/
│   └── app_theme.dart       # Noir theme definition
├── models/
│   ├── prompt_item.dart
│   ├── style_preset.dart
│   └── pipeline_run.dart
├── services/
│   ├── storage_service.dart     # SharedPreferences wrapper
│   ├── parser_service.dart      # Multi-format prompt parsing
│   └── pipeline_service.dart    # Processing pipeline logic
├── providers/
│   ├── editor_provider.dart
│   ├── pipeline_provider.dart
│   └── settings_provider.dart
├── screens/
│   ├── editor_screen.dart
│   ├── pipeline_screen.dart
│   └── settings_screen.dart
└── widgets/
    ├── prompt_card.dart
    ├── section_card.dart
    ├── pipeline_visualizer.dart
    ├── batch_chunk_card.dart
    ├── history_card.dart
    ├── stat_grid.dart
    └── style_preset_manager.dart
```

### State Management
- **Provider**: Change notification-based state management
- **EditorProvider**: Manages prompt list, parsing, and selection
- **PipelineProvider**: Handles all pipeline settings and output
- **SettingsProvider**: Application preferences and presets

### Persistence
All state is persisted via SharedPreferences:
- Active tab and input text
- Environment variables
- Style presets (JSON serialized)
- Pipeline settings and history
- All toggle states

## Requirements

- Flutter 3.x
- Dart 3.x
- Android 6.0+ (API 23)
- Target Android 14 (API 34)

## Dependencies

- `shared_preferences` - Local persistence
- `google_fonts` - Inter & JetBrains Mono typography
- `provider` - State management
- `share_plus` - Platform-native sharing
- `path_provider` - File path access
- `uuid` - Unique ID generation

## Getting Started

### Prerequisites
```bash
flutter pub get
```

### Run Development
```bash
flutter run
```

### Build APK
```bash
flutter build apk --release
```

### Build App Bundle
```bash
flutter build appbundle --release
```

## Key Classes

### ParserService
Detects and parses multiple prompt formats:
- Blank line separation
- Numbered (1., 1), 01.)
- Lettered (A., A))
- Scene tags ([Scene 01], ## Scene, Scene:)
- Custom delimiters

### PipelineService
Executes full processing pipeline with:
- Scene splitting by word count
- Variable substitution
- Find & replace
- Style injection
- Prefix/suffix wrapping
- Scene numbering
- Range slicing
- Batch chunking
- Telemetry collection

### StorageService
Wraps SharedPreferences with typed getters/setters for:
- UI state (active tab, inputs)
- Pipeline configuration
- Environment variables
- Style presets
- Processing history
- All toggle states

## UI Components

### PromptCard
- Editable multiline text field
- Index number (gold, monospace)
- Word count chip
- Copy, delete, drag-handle buttons
- Selection checkbox in bulk mode

### SectionCard
- ExpansionTile with left 3px crimson border
- Toggle ON/OFF badge
- Animated expansion

### PipelineVisualizer
- Horizontal stepper showing 9 processing steps
- Pulse animation on active step
- Gold connector lines animation on completion

### StatGrid
- 2x3 grid of telemetry statistics
- Each stat in its own card with gold accent

## Notes

- Fully offline app - no internet required
- Single APK build (no flavors)
- Zero external API calls (except optional share to system apps)
- All fonts embedded in binary
- No dark mode toggle - locked to premium Noir aesthetic
- Last 20 pipeline runs stored in history

## Future Enhancements

- Export to Replicate/Midjourney API endpoints
- Import from external prompt libraries
- Advanced regex find & replace
- Prompt versioning and branching
- Analytics on processed content
- Custom theme creation

---

Built with Flutter & Provider for professional documentary content creators.
