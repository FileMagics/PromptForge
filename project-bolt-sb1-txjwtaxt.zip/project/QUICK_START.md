# PromptForge Pro - Quick Start Guide

## Prerequisites

- Flutter 3.x installed
- Dart 3.x (included with Flutter)
- Android SDK with API 34
- Android device or emulator (Android 6.0+)

## Setup & Installation

### 1. Get Dependencies
```bash
cd /path/to/promptforge_pro
flutter pub get
```

### 2. Run Development Build
```bash
flutter run
```

### 3. Build Release APK
```bash
flutter build apk --release
```
Output: `build/app/outputs/apk/release/app-release.apk`

### 4. Build App Bundle (Google Play)
```bash
flutter build appbundle --release
```
Output: `build/app/outputs/bundle/release/app-release.aab`

---

## Using the App

### Editor Tab (First Screen)

1. **Parse Prompts**
   - Paste a prompt block into the "Import Section"
   - Click "Parse & Load"
   - App auto-detects format and shows:
     - Detected format badge
     - Total prompt count
     - Total word count

2. **Edit Prompts**
   - Click any prompt card to edit text
   - Reorder by dragging the drag-handle icon
   - Word count updates automatically

3. **Bulk Operations**
   - Long-press or click "Bulk Select" button
   - Check boxes to select prompts
   - Choose: Delete, Copy as Block, or Apply Style

4. **Scene Management**
   - Click "Scene Manager" button
   - Choose format: [Scene 01], 1., or A.
   - Apply to strip and re-index

5. **Export**
   - Click "Export" button
   - Choose format: Plain Text, Numbered, or JSON
   - Share via system share sheet

---

### Pipeline Tab (Second Screen)

The pipeline is a 9-step processing workflow. Sections can be toggled ON/OFF individually.

#### Step 1: Input Payload
- Paste raw prompt text
- Click "Clear" or manually clean up
- View word count

#### Step 2: Scene Splitter
- Enable toggle
- Enter words per scene (default: 20)
- Automatically splits input by word count

#### Step 3: Environment Variables
- Add key-value pairs (e.g., STYLE=noir)
- Click "Auto-Detect" to find {{VAR}} patterns
- Variables used as `{{KEY}}` in prompts

#### Step 4: Global Find & Replace
- Enable toggle
- Enter find and replace text
- Applied to all prompts

#### Step 5: Style Injection
- Enable toggle
- Select or create style presets
- Edit style text directly
- Applied to END of every prompt

#### Step 6: Prefix & Suffix
- Enable each independently
- Prefix examples: "/imagine prompt:"
- Suffix examples: "--v 6.0 --ar 16:9"

#### Step 7: Scene Indexing
- Enable toggle
- Choose format: [Scene 01], 1., or A.
- Prepended to each prompt

#### Step 8: Slice & Range
- Enable toggle
- Set start and end scene numbers
- Quick chips: "First 10", "Last 10", "Middle 50%"

#### Step 9: Compile & Export
- Click "Compile Pipeline" button at bottom
- View results in tabs:
  - Final Source: After all steps
  - Env Applied: After variables
  - Style Applied: After styling
- Copy All or Download .txt

---

### Batch Export
After compilation, section I shows batches:
- Each chunk shows: scene range, preview, copy button
- Click "Copy All Chunks" to copy all batches

---

### History Panel
- Shows last 20 compiled pipelines
- Each entry shows: preset name, scene count, timestamp, input preview
- Click "Restore" to reload that pipeline state
- Click "Clear History" to delete all entries

---

### Telemetry
Shows real-time stats after compilation:
- Total Scenes
- Word Count
- Variables Replaced
- Process Time (ms)
- Avg Words/Scene
- Batch Chunks
- Validation log with success/warning/error messages

---

### Settings Tab (Top Right Icon)

1. **Theme** - Locked to Dark Noir (no options)
2. **Default Batch Size** - Scenes per chunk (default: 10)
3. **Default Style Preset** - Pre-selected when opening pipeline
4. **Default Indexing Format** - [Scene 01], 1., or A.
5. **Clear All Data** - Wipes prompts, history, settings (confirmation required)
6. **About** - App info, version v3.0, built-with tags

---

## Example Workflow

### Example 1: Process Midjourney Prompts

1. **Editor Tab**
   - Paste 50 prompts (one per line)
   - App detects blank-line format
   - Reviews word count

2. **Pipeline Tab**
   - Input: 50 prompts
   - Enable Splitter: 30 words/scene
   - Becomes: ~75 scenes
   - Enable Style: Select "Noir Cinematic" preset
   - Enable Indexing: Format [Scene 01]
   - Enable Prefix/Suffix:
     - Prefix: "/imagine prompt:"
     - Suffix: "--v 6"
   - Click "Compile Pipeline"

3. **Results**
   - Scenes split and numbered: [Scene 001] prompt text... --v 6
   - Telemetry shows: 75 scenes, ~2,250 words, processed in 145ms
   - Batch Export splits into 8 chunks (10 scenes each)

4. **Export**
   - Copy all chunks or individual chunks
   - Paste into Midjourney batch upscaler

---

### Example 2: Documentary Narration Prompts

1. **Editor Tab**
   - Paste script with "Scene 1:", "Scene 2:", etc.
   - App detects scene tag format
   - 30 scenes detected

2. **Pipeline Tab**
   - Input: 30 scenes of narration
   - Add Environment Variables:
     - TONE = "investigative noir"
     - LENGTH = "15-second narration"
   - Enable Find & Replace:
     - Find: "{{TONE}}"
     - Replace: "investigative noir"
   - Enable Style: "Documentary Cinematic"
   - Compile

3. **Export**
   - Download as .txt
   - Paste into voice generator

---

## Keyboard Shortcuts

- None (touch/gesture-based UI)
- Long-press prompt card to enter selection mode
- Swipe down to scroll to top (use scroll-to-top button)

---

## Data Storage

All data stored locally in SharedPreferences:
- No cloud sync
- No login required
- Survives app uninstall if device has backup enabled
- Can be cleared from Settings

---

## Troubleshooting

### "Please enter prompts first"
- Add text in Input Payload section
- Click Parse & Load (for Editor) or Compile (for Pipeline)

### Prompts not parsing correctly
- Try selecting different format in Scene Manager (Editor)
- Check for blank lines between prompts
- Manually paste format examples if needed

### Style not applying
- Enable toggle in Section E
- Verify style text is not empty
- Recompile pipeline

### Memory issues with large batches
- Reduce batch size in settings
- Process in smaller chunks
- Close other apps

---

## Tips & Tricks

1. **Use Presets**: Save frequently-used styles as presets for quick access
2. **Auto-Detect Variables**: Let the app find {{VAR}} patterns automatically
3. **History Restoration**: Quickly restore previous pipeline runs without manual config
4. **Batch Processing**: Use batch export to feed results to external tools
5. **Scene Splitting**: Adjust words-per-scene based on your tool's input limits

---

## Export Formats

### Plain Text
```
Prompt 1 text here

Prompt 2 text here

Prompt 3 text here
```

### Numbered
```
1. Prompt 1 text here

2. Prompt 2 text here

3. Prompt 3 text here
```

### JSON
```json
{
  "prompts": [
    {"index": 0, "text": "Prompt 1 text here"},
    {"index": 1, "text": "Prompt 2 text here"},
    {"index": 2, "text": "Prompt 3 text here"}
  ]
}
```

---

## Support & Issues

This is a standalone offline application. Common issues:

- **App crashes on startup**: Clear app data in Settings > Apps > PromptForge Pro
- **Old data not showing**: Check if you've cleared all data previously
- **Export not working**: Ensure device has storage permissions
- **Theme looks wrong**: Only Dark Noir theme is available (no light mode)

---

## Next Steps

1. Download and install the app
2. Try parsing your existing prompts
3. Explore the pipeline with one prompt
4. Save a custom style preset
5. Process a larger batch and review telemetry
6. Export and test in your AI tool

Enjoy! 🎬
