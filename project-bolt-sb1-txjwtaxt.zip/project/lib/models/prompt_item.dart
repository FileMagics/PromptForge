import 'package:uuid/uuid.dart';

class PromptItem {
  final String id;
  final String text;
  final int index;
  bool isSelected;

  PromptItem({
    String? id,
    required this.text,
    required this.index,
    this.isSelected = false,
  }) : id = id ?? const Uuid().v4();

  int get wordCount => text.split(RegExp(r'\s+')).where((word) => word.isNotEmpty).length;

  PromptItem copyWith({
    String? id,
    String? text,
    int? index,
    bool? isSelected,
  }) {
    return PromptItem(
      id: id ?? this.id,
      text: text ?? this.text,
      index: index ?? this.index,
      isSelected: isSelected ?? this.isSelected,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'text': text,
    'index': index,
  };

  factory PromptItem.fromJson(Map<String, dynamic> json) {
    return PromptItem(
      id: json['id'] as String,
      text: json['text'] as String,
      index: json['index'] as int,
    );
  }
}
