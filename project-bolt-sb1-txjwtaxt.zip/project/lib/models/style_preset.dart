import 'package:uuid/uuid.dart';

class StylePreset {
  final String id;
  final String name;
  final String styleText;

  StylePreset({
    String? id,
    required this.name,
    required this.styleText,
  }) : id = id ?? const Uuid().v4();

  StylePreset copyWith({
    String? id,
    String? name,
    String? styleText,
  }) {
    return StylePreset(
      id: id ?? this.id,
      name: name ?? this.name,
      styleText: styleText ?? this.styleText,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'styleText': styleText,
  };

  factory StylePreset.fromJson(Map<String, dynamic> json) {
    return StylePreset(
      id: json['id'] as String,
      name: json['name'] as String,
      styleText: json['styleText'] as String,
    );
  }

  static StylePreset defaultPreset() {
    return StylePreset(
      name: 'Noir Cinematic',
      styleText:
          'Style: 2D Cinematic Graphic Novel Art, noir-inspired lighting, muted palette (deep red, charcoal, gold), money/greed aesthetic, sharp shadows, corporate corruption feel, premium investigative documentary visuals.',
    );
  }
}
