import 'package:uuid/uuid.dart';

class PipelineRun {
  final String id;
  final DateTime timestamp;
  final int sceneCount;
  final String presetName;
  final String inputPreview;
  final Map<String, dynamic> pipelineState;

  PipelineRun({
    String? id,
    DateTime? timestamp,
    required this.sceneCount,
    required this.presetName,
    required this.inputPreview,
    required this.pipelineState,
  })  : id = id ?? const Uuid().v4(),
        timestamp = timestamp ?? DateTime.now();

  Map<String, dynamic> toJson() => {
    'id': id,
    'timestamp': timestamp.toIso8601String(),
    'sceneCount': sceneCount,
    'presetName': presetName,
    'inputPreview': inputPreview,
    'pipelineState': pipelineState,
  };

  factory PipelineRun.fromJson(Map<String, dynamic> json) {
    return PipelineRun(
      id: json['id'] as String,
      timestamp: DateTime.parse(json['timestamp'] as String),
      sceneCount: json['sceneCount'] as int,
      presetName: json['presetName'] as String,
      inputPreview: json['inputPreview'] as String,
      pipelineState: Map<String, dynamic>.from(json['pipelineState'] as Map),
    );
  }
}
