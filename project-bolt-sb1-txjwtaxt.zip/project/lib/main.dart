import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'theme/app_theme.dart';
import 'services/storage_service.dart';
import 'providers/editor_provider.dart';
import 'providers/pipeline_provider.dart';
import 'providers/settings_provider.dart';
import 'screens/editor_screen.dart';
import 'screens/pipeline_screen.dart';
import 'screens/settings_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final storageService = StorageService();
  await storageService.init();

  runApp(MyApp(storageService: storageService));
}

class MyApp extends StatelessWidget {
  final StorageService storageService;

  const MyApp({required this.storageService, Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        Provider<StorageService>.value(value: storageService),
        ChangeNotifierProvider(create: (_) => EditorProvider()),
        ChangeNotifierProvider(create: (_) => PipelineProvider()),
        ChangeNotifierProxyProvider<StorageService, SettingsProvider>(
          create: (context) => SettingsProvider(storage: storageService),
          update: (context, storage, previous) => previous ?? SettingsProvider(storage: storage),
        ),
      ],
      child: MaterialApp(
        title: 'PromptForge Pro',
        theme: AppTheme.darkTheme,
        home: const HomePage(),
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _selectedIndex = 0;

  @override
  void initState() {
    super.initState();
    _initializeApp();
  }

  Future<void> _initializeApp() async {
    final storageService = context.read<StorageService>();
    final settingsProvider = context.read<SettingsProvider>();
    final editorProvider = context.read<EditorProvider>();
    final pipelineProvider = context.read<PipelineProvider>();

    // Initialize settings
    await settingsProvider.init();

    // Restore active tab
    final activeTab = await storageService.getActiveTab();
    setState(() => _selectedIndex = activeTab);

    // Restore editor state
    final editorInput = await storageService.getEditorInput();
    if (editorInput.isNotEmpty) {
      editorProvider.inputText = editorInput;
    }

    // Restore pipeline state
    final pipelineInput = await storageService.getPipelineInput();
    pipelineProvider.setInputText(pipelineInput);

    final variables = await storageService.getVariables();
    pipelineProvider.setVariables(variables);

    final splitterEnabled = await storageService.isSplitterEnabled();
    pipelineProvider.setSplitterEnabled(splitterEnabled);

    final splitterWordsPerScene = await storageService.getSplitterWordsPerScene();
    pipelineProvider.setSplitterWordsPerScene(splitterWordsPerScene);

    final styleEnabled = await storageService.isStyleEnabled();
    pipelineProvider.setStyleEnabled(styleEnabled);

    final prefixEnabled = await storageService.isPrefixEnabled();
    pipelineProvider.setPrefixEnabled(prefixEnabled);

    final prefix = await storageService.getPrefix();
    pipelineProvider.setPrefixText(prefix);

    final suffixEnabled = await storageService.isSuffixEnabled();
    pipelineProvider.setSuffixEnabled(suffixEnabled);

    final suffix = await storageService.getSuffix();
    pipelineProvider.setSuffixText(suffix);

    final indexingEnabled = await storageService.isIndexingEnabled();
    pipelineProvider.setIndexingEnabled(indexingEnabled);

    final indexingFormat = await storageService.getIndexingFormat();
    pipelineProvider.setIndexingFormat(indexingFormat);

    final sliceEnabled = await storageService.isSliceEnabled();
    pipelineProvider.setSliceEnabled(sliceEnabled);

    final sliceFrom = await storageService.getSliceFrom();
    pipelineProvider.setSliceFrom(sliceFrom);

    final sliceTo = await storageService.getSliceTo();
    pipelineProvider.setSliceTo(sliceTo);

    final findReplaceEnabled = await storageService.isFindReplaceEnabled();
    pipelineProvider.setFindReplaceEnabled(findReplaceEnabled);

    final batchSize = await storageService.getBatchSize();
    pipelineProvider.setBatchSize(batchSize);

    final history = await storageService.getPipelineHistory();
    pipelineProvider.setHistory(history);
  }

  void _onTabChanged(int index) {
    setState(() => _selectedIndex = index);
    context.read<StorageService>().setActiveTab(index);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            const Text('PromptForge Pro'),
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: AppColors.primaryAccent,
                borderRadius: BorderRadius.circular(4),
              ),
              child: const Text(
                'v3.0',
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                  color: AppColors.secondaryAccent,
                ),
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const SettingsScreen()),
              );
            },
          ),
        ],
      ),
      body: _selectedIndex == 0 ? const EditorScreen() : const PipelineScreen(),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _selectedIndex,
        onDestinationSelected: _onTabChanged,
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.edit_note),
            label: 'Editor',
          ),
          NavigationDestination(
            icon: Icon(Icons.account_tree),
            label: 'Pipeline',
          ),
        ],
      ),
    );
  }
}
