import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/settings_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/section_card.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Consumer<SettingsProvider>(
        builder: (context, settingsProvider, _) {
          return SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  // Theme Section
                  SectionCard(
                    title: 'Theme',
                    icon: Icons.palette,
                    enabled: true,
                    onEnabledChanged: null,
                    content: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: AppColors.background,
                            border: Border.all(color: AppColors.borderColor),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Row(
                            children: [
                              Icon(Icons.dark_mode, color: AppColors.primaryAccent),
                              const SizedBox(width: 12),
                              const Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Dark Noir',
                                      style: TextStyle(
                                        fontWeight: FontWeight.w600,
                                        color: AppColors.textPrimary,
                                      ),
                                    ),
                                    Text(
                                      'Locked to premium noir aesthetic',
                                      style: TextStyle(
                                        fontSize: 12,
                                        color: AppColors.textSecondary,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const Icon(Icons.lock, color: AppColors.secondaryAccent),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),

                  // Default Batch Size
                  SectionCard(
                    title: 'Default Batch Size',
                    icon: Icons.inventory_2,
                    enabled: true,
                    onEnabledChanged: null,
                    content: Column(
                      children: [
                        TextField(
                          keyboardType: TextInputType.number,
                          onChanged: (value) {
                            if (value.isNotEmpty) {
                              settingsProvider.setDefaultBatchSize(int.parse(value));
                            }
                          },
                          decoration: InputDecoration(
                            labelText: 'Scenes per batch',
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(4)),
                            hintText: '10',
                          ),
                          controller: TextEditingController(
                            text: settingsProvider.defaultBatchSize.toString(),
                          ),
                        ),
                      ],
                    ),
                  ),

                  // Default Style Preset
                  SectionCard(
                    title: 'Default Style Preset',
                    icon: Icons.style,
                    enabled: true,
                    onEnabledChanged: null,
                    content: Column(
                      children: [
                        DropdownButton<String>(
                          value: settingsProvider.defaultStylePreset,
                          isExpanded: true,
                          dropdownColor: AppColors.surface,
                          style: const TextStyle(color: AppColors.textPrimary),
                          items: settingsProvider.stylePresets
                              .map((preset) => DropdownMenuItem(
                                    value: preset.name,
                                    child: Text(preset.name),
                                  ))
                              .toList(),
                          onChanged: (value) {
                            if (value != null) {
                              settingsProvider.setDefaultStylePreset(value);
                            }
                          },
                        ),
                      ],
                    ),
                  ),

                  // Default Indexing Format
                  SectionCard(
                    title: 'Default Indexing Format',
                    icon: Icons.tag,
                    enabled: true,
                    onEnabledChanged: null,
                    content: Column(
                      children: [
                        SegmentedButton<String>(
                          segments: const [
                            ButtonSegment(label: Text('[Scene 01]'), value: '[Scene 01]'),
                            ButtonSegment(label: Text('1.'), value: '1.'),
                            ButtonSegment(label: Text('A.'), value: 'A.'),
                          ],
                          selected: {settingsProvider.defaultIndexingFormat},
                          onSelectionChanged: (value) {
                            settingsProvider.setDefaultIndexingFormat(value.first);
                          },
                        ),
                      ],
                    ),
                  ),

                  // Data Management
                  SectionCard(
                    title: 'Data Management',
                    icon: Icons.storage,
                    enabled: true,
                    onEnabledChanged: null,
                    content: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: AppColors.background,
                            border: Border.all(color: AppColors.borderColor),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Clear All Data',
                                style: Theme.of(context).textTheme.labelMedium,
                              ),
                              const SizedBox(height: 4),
                              const Text(
                                'This will permanently delete all your prompts, settings, and history.',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: AppColors.textSecondary,
                                ),
                              ),
                              const SizedBox(height: 12),
                              SizedBox(
                                width: double.infinity,
                                child: ElevatedButton.icon(
                                  onPressed: () {
                                    showDialog(
                                      context: context,
                                      builder: (ctx) => AlertDialog(
                                        backgroundColor: AppColors.surface,
                                        title: const Text('Clear All Data?'),
                                        content: const Text(
                                          'This action cannot be undone. All your data will be permanently deleted.',
                                        ),
                                        actions: [
                                          TextButton(
                                            onPressed: () => Navigator.pop(ctx),
                                            child: const Text('Cancel'),
                                          ),
                                          ElevatedButton(
                                            onPressed: () {
                                              settingsProvider.clearAllData();
                                              Navigator.pop(ctx);
                                              ScaffoldMessenger.of(context).showSnackBar(
                                                const SnackBar(
                                                  content: Text('All data cleared'),
                                                ),
                                              );
                                            },
                                            child: const Text('Delete All'),
                                          ),
                                        ],
                                      ),
                                    );
                                  },
                                  icon: const Icon(Icons.delete, size: 16),
                                  label: const Text('Clear All'),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),

                  // About Section
                  SectionCard(
                    title: 'About',
                    icon: Icons.info,
                    enabled: true,
                    onEnabledChanged: null,
                    initiallyExpanded: false,
                    content: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: AppColors.background,
                            border: Border.all(color: AppColors.borderColor),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  const Text('App Name'),
                                  Text(
                                    'PromptForge Pro',
                                    style: Theme.of(context).textTheme.labelMedium?.copyWith(
                                      color: AppColors.secondaryAccent,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 12),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  const Text('Version'),
                                  Text(
                                    'v3.0.0',
                                    style: Theme.of(context).textTheme.labelMedium?.copyWith(
                                      color: AppColors.secondaryAccent,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 12),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text('Tagline'),
                                  const SizedBox(height: 4),
                                  const Text(
                                    'Professional AI prompt processing and management for documentary content creators.',
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: AppColors.textSecondary,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 12),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text('Built with'),
                                  const SizedBox(height: 4),
                                  Wrap(
                                    spacing: 8,
                                    children: [
                                      Chip(
                                        label: const Text('Flutter 3.x'),
                                        backgroundColor: AppColors.primaryAccent,
                                        labelStyle: const TextStyle(
                                          color: AppColors.secondaryAccent,
                                          fontSize: 11,
                                        ),
                                      ),
                                      Chip(
                                        label: const Text('Noir Theme'),
                                        backgroundColor: AppColors.primaryAccent,
                                        labelStyle: const TextStyle(
                                          color: AppColors.secondaryAccent,
                                          fontSize: 11,
                                        ),
                                      ),
                                      Chip(
                                        label: const Text('Offline-First'),
                                        backgroundColor: AppColors.primaryAccent,
                                        labelStyle: const TextStyle(
                                          color: AppColors.secondaryAccent,
                                          fontSize: 11,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 24),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
