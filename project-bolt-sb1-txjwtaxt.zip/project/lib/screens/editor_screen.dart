import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/prompt_item.dart';
import '../providers/editor_provider.dart';
import '../services/parser_service.dart';
import '../theme/app_theme.dart';
import '../widgets/prompt_card.dart';

class EditorScreen extends StatefulWidget {
  const EditorScreen({Key? key}) : super(key: key);

  @override
  State<EditorScreen> createState() => _EditorScreenState();
}

class _EditorScreenState extends State<EditorScreen> {
  late TextEditingController _importController;

  @override
  void initState() {
    super.initState();
    _importController = TextEditingController();
  }

  @override
  void dispose() {
    _importController.dispose();
    super.dispose();
  }

  void _showSceneManagerBottomSheet() {
    showModalBottomSheet(
      context: context,
      builder: (context) => _SceneManagerBottomSheet(
        onFormatChanged: (newFormat) {
          final provider = Provider.of<EditorProvider>(context, listen: false);
          for (int i = 0; i < provider.prompts.length; i++) {
            provider.updatePrompt(
              i,
              _stripSceneNumber(provider.prompts[i].text),
            );
          }
        },
      ),
    );
  }

  void _showExportBottomSheet() {
    showModalBottomSheet(
      context: context,
      builder: (context) => _ExportBottomSheet(),
    );
  }

  String _stripSceneNumber(String text) {
    return text.replaceAll(RegExp(r'^[\[\(]?[Ss]cene\s+\d+[\]\)]?\s*'), '')
        .replaceAll(RegExp(r'^\d+[\.\)]\s*'), '')
        .replaceAll(RegExp(r'^[A-Za-z][\.\)]\s*'), '');
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<EditorProvider>(
      builder: (context, provider, child) {
        return SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Import Section
                Container(
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    border: Border(left: BorderSide(color: AppColors.primaryAccent, width: 3)),
                    boxShadow: [AppTheme.mediumDropShadow],
                  ),
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Import Section',
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: _importController,
                        maxLines: 6,
                        style: const TextStyle(
                          fontFamily: 'JetBrains Mono',
                          fontSize: 13,
                          color: AppColors.textPrimary,
                        ),
                        decoration: InputDecoration(
                          hintText: 'Paste prompt block here...',
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(4),
                            borderSide: const BorderSide(color: AppColors.borderColor),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(4),
                            borderSide: const BorderSide(color: AppColors.borderColor),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(4),
                            borderSide: const BorderSide(color: AppColors.primaryAccent, width: 2),
                          ),
                          filled: true,
                          fillColor: AppColors.background,
                        ),
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Expanded(
                            child: ElevatedButton.icon(
                              onPressed: () {
                                provider.parseInput(_importController.text);
                              },
                              icon: const Icon(Icons.upload_file, size: 16),
                              label: const Text('Parse & Load'),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: OutlinedButton.icon(
                              onPressed: _showSceneManagerBottomSheet,
                              icon: const Icon(Icons.settings, size: 16),
                              label: const Text('Scene Manager'),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      if (provider.detectedFormat.isNotEmpty)
                        Row(
                          children: [
                            Chip(
                              label: Text(provider.detectedFormat),
                              backgroundColor: AppColors.primaryAccent,
                              labelStyle: const TextStyle(color: AppColors.secondaryAccent),
                            ),
                            const SizedBox(width: 8),
                            Chip(
                              label: Text('${provider.prompts.length} prompts'),
                              backgroundColor: AppColors.idle,
                            ),
                            const SizedBox(width: 8),
                            Chip(
                              label: Text('${provider.totalWords} words'),
                              backgroundColor: AppColors.idle,
                            ),
                          ],
                        ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),

                // Selection Mode Bar
                if (provider.selectionMode)
                  Container(
                    decoration: BoxDecoration(
                      color: AppColors.primaryAccent,
                      boxShadow: [AppTheme.heavyDropShadow],
                    ),
                    padding: const EdgeInsets.all(12),
                    child: Row(
                      children: [
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: provider.selectAllPrompts,
                            icon: const Icon(Icons.select_all, size: 16),
                            label: const Text('Select All'),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: provider.deselectAllPrompts,
                            icon: const Icon(Icons.deselect, size: 16),
                            label: const Text('Deselect'),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: ElevatedButton.icon(
                            onPressed: provider.deleteSelectedPrompts,
                            icon: const Icon(Icons.delete, size: 16),
                            label: const Text('Delete'),
                          ),
                        ),
                      ],
                    ),
                  ),
                const SizedBox(height: 12),

                // Prompts List
                if (provider.prompts.isEmpty)
                  Center(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 40),
                      child: Column(
                        children: [
                          Icon(Icons.inbox, size: 48, color: AppColors.textSecondary),
                          const SizedBox(height: 12),
                          Text(
                            'No prompts yet. Parse a block above to get started.',
                            style: Theme.of(context).textTheme.bodyMedium,
                            textAlign: TextAlign.center,
                          ),
                        ],
                      ),
                    ),
                  )
                else
                  ReorderableListView(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    onReorder: (oldIndex, newIndex) => provider.reorderPrompts(oldIndex, newIndex),
                    children: [
                      for (int i = 0; i < provider.prompts.length; i++)
                        PromptCard(
                          key: ValueKey(provider.prompts[i].id),
                          prompt: provider.prompts[i],
                          index: i,
                          selectionMode: provider.selectionMode,
                          onDelete: () => provider.removePrompt(i),
                          onTextChanged: (text) => provider.updatePrompt(i, text),
                          onToggleSelection: () => provider.togglePromptSelection(i),
                        ),
                    ],
                  ),
                const SizedBox(height: 12),
                if (provider.prompts.isNotEmpty)
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: provider.toggleSelectionMode,
                          icon: const Icon(Icons.check_circle_outline, size: 16),
                          label: Text(provider.selectionMode ? 'Exit Selection' : 'Bulk Select'),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: _showExportBottomSheet,
                          icon: const Icon(Icons.share, size: 16),
                          label: const Text('Export'),
                        ),
                      ),
                    ],
                  ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: provider.addPrompt,
                    icon: const Icon(Icons.add, size: 18),
                    label: const Text('Add Prompt'),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _SceneManagerBottomSheet extends StatefulWidget {
  final Function(String) onFormatChanged;

  const _SceneManagerBottomSheet({required this.onFormatChanged});

  @override
  State<_SceneManagerBottomSheet> createState() => _SceneManagerBottomSheetState();
}

class _SceneManagerBottomSheetState extends State<_SceneManagerBottomSheet> {
  String _selectedFormat = '[Scene 01]';

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.surface,
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Scene Number Manager', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 16),
          Text('Format:', style: Theme.of(context).textTheme.bodyMedium),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            children: ['[Scene 01]', '1.', 'A.'].map((format) {
              return FilterChip(
                label: Text(format),
                selected: _selectedFormat == format,
                onSelected: (selected) {
                  setState(() => _selectedFormat = format);
                  widget.onFormatChanged(format);
                },
                selectedColor: AppColors.primaryAccent,
                labelStyle: TextStyle(
                  color: _selectedFormat == format ? AppColors.secondaryAccent : AppColors.textPrimary,
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Apply'),
            ),
          ),
        ],
      ),
    );
  }
}

class _ExportBottomSheet extends StatefulWidget {
  const _ExportBottomSheet();

  @override
  State<_ExportBottomSheet> createState() => _ExportBottomSheetState();
}

class _ExportBottomSheetState extends State<_ExportBottomSheet> {
  String _exportFormat = 'Plain Text';

  @override
  Widget build(BuildContext context) {
    return Consumer<EditorProvider>(
      builder: (context, provider, _) {
        return Container(
          color: AppColors.surface,
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Export Options', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 16),
              Text('Format:', style: Theme.of(context).textTheme.bodyMedium),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                children: ['Plain Text', 'Numbered', 'JSON'].map((format) {
                  return FilterChip(
                    label: Text(format),
                    selected: _exportFormat == format,
                    onSelected: (selected) => setState(() => _exportFormat = format),
                    selectedColor: AppColors.primaryAccent,
                    labelStyle: TextStyle(
                      color: _exportFormat == format ? AppColors.secondaryAccent : AppColors.textPrimary,
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text('Cancel'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: () {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Exported successfully!')),
                        );
                        Navigator.pop(context);
                      },
                      icon: const Icon(Icons.share, size: 16),
                      label: const Text('Share'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}
