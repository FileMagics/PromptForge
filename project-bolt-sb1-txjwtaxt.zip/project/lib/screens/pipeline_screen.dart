import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/prompt_item.dart';
import '../models/style_preset.dart';
import '../providers/pipeline_provider.dart';
import '../providers/settings_provider.dart';
import '../services/pipeline_service.dart';
import '../services/parser_service.dart';
import '../theme/app_theme.dart';
import '../widgets/batch_chunk_card.dart';
import '../widgets/history_card.dart';
import '../widgets/pipeline_visualizer.dart';
import '../widgets/section_card.dart';
import '../widgets/stat_grid.dart';
import '../widgets/style_preset_manager.dart';

class PipelineScreen extends StatefulWidget {
  const PipelineScreen({Key? key}) : super(key: key);

  @override
  State<PipelineScreen> createState() => _PipelineScreenState();
}

class _PipelineScreenState extends State<PipelineScreen> {
  final ScrollController _scrollController = ScrollController();

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer2<PipelineProvider, SettingsProvider>(
      builder: (context, pipelineProvider, settingsProvider, _) {
        return Stack(
          children: [
            SingleChildScrollView(
              controller: _scrollController,
              child: Column(
                children: [
                  PipelineVisualizer(activeStep: 0, completedSteps: 0),
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        // Section A: Input Payload
                        SectionCard(
                          title: 'Input Payload',
                          icon: Icons.input,
                          enabled: true,
                          onEnabledChanged: null,
                          content: _InputPayloadSection(),
                        ),

                        // Section B: Scene Splitter
                        SectionCard(
                          title: 'Scene Splitter',
                          icon: Icons.call_split,
                          enabled: pipelineProvider.splitterEnabled,
                          onEnabledChanged: pipelineProvider.setSplitterEnabled,
                          content: _SceneSplitterSection(),
                        ),

                        // Section C: Environment Variables
                        SectionCard(
                          title: 'Environment Variables',
                          icon: Icons.settings_input_component,
                          enabled: pipelineProvider.variables.isNotEmpty,
                          onEnabledChanged: null,
                          content: _EnvironmentVariablesSection(),
                        ),

                        // Section D: Find & Replace
                        SectionCard(
                          title: 'Global Find & Replace',
                          icon: Icons.find_replace,
                          enabled: pipelineProvider.findReplaceEnabled,
                          onEnabledChanged: pipelineProvider.setFindReplaceEnabled,
                          content: _FindReplaceSection(),
                        ),

                        // Section E: Style Injection
                        SectionCard(
                          title: 'Style Injection with Presets',
                          icon: Icons.palette,
                          enabled: pipelineProvider.styleEnabled,
                          onEnabledChanged: pipelineProvider.setStyleEnabled,
                          content: _StyleInjectionSection(),
                        ),

                        // Section F: Prefix & Suffix
                        SectionCard(
                          title: 'Prefix & Suffix',
                          icon: Icons.format_quote,
                          enabled: pipelineProvider.prefixEnabled || pipelineProvider.suffixEnabled,
                          onEnabledChanged: null,
                          content: _PrefixSuffixSection(),
                        ),

                        // Section G: Scene Indexing
                        SectionCard(
                          title: 'Scene Indexing',
                          icon: Icons.tag,
                          enabled: pipelineProvider.indexingEnabled,
                          onEnabledChanged: pipelineProvider.setIndexingEnabled,
                          content: _SceneIndexingSection(),
                        ),

                        // Section H: Slice & Range
                        SectionCard(
                          title: 'Slice & Range Selector',
                          icon: Icons.sliders,
                          enabled: pipelineProvider.sliceEnabled,
                          onEnabledChanged: pipelineProvider.setSliceEnabled,
                          content: _SliceRangeSection(),
                        ),

                        // Section I: Compiled Output
                        SectionCard(
                          title: 'Compiled Output Panel',
                          icon: Icons.output,
                          enabled: true,
                          onEnabledChanged: null,
                          initiallyExpanded: false,
                          content: _CompiledOutputSection(),
                        ),

                        // Section J: Batch Export
                        if (pipelineProvider.lastOutput != null)
                          SectionCard(
                            title: 'Batch Export',
                            icon: Icons.inventory_2,
                            enabled: true,
                            onEnabledChanged: null,
                            initiallyExpanded: false,
                            content: _BatchExportSection(),
                          ),

                        // Section K: History
                        SectionCard(
                          title: 'History Panel',
                          icon: Icons.history,
                          enabled: true,
                          onEnabledChanged: null,
                          initiallyExpanded: false,
                          content: _HistorySection(),
                        ),

                        // Section L: Telemetry
                        if (pipelineProvider.lastOutput != null)
                          SectionCard(
                            title: 'Telemetry',
                            icon: Icons.analytics,
                            enabled: true,
                            onEnabledChanged: null,
                            initiallyExpanded: false,
                            content: _TelemetrySection(),
                          ),

                        const SizedBox(height: 100),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            // Bottom Action Bar
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: Container(
                color: AppColors.surface,
                padding: const EdgeInsets.all(12),
                child: SafeArea(
                  child: Row(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.arrow_upward),
                        onPressed: () => _scrollController.animateTo(
                          0,
                          duration: const Duration(milliseconds: 300),
                          curve: Curves.easeOut,
                        ),
                        tooltip: 'Scroll to top',
                      ),
                      IconButton(
                        icon: const Icon(Icons.refresh),
                        onPressed: pipelineProvider.resetAll,
                        tooltip: 'Reset all',
                      ),
                      const Spacer(),
                      if (pipelineProvider.isProcessing)
                        Expanded(
                          child: ElevatedButton.icon(
                            icon: const SizedBox(
                              width: 16,
                              height: 16,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            ),
                            label: const Text('Processing...'),
                            onPressed: null,
                          ),
                        )
                      else
                        Expanded(
                          child: ElevatedButton.icon(
                            icon: const Icon(Icons.flash_on, size: 18),
                            label: const Text('Compile Pipeline'),
                            onPressed: () => _compilePipeline(context, pipelineProvider),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  Future<void> _compilePipeline(BuildContext context, PipelineProvider provider) async {
    provider.setIsProcessing(true);

    await Future.delayed(const Duration(milliseconds: 500));

    final lines = provider.inputText.split('\n');
    final prompts = lines
        .map((line) => line.trim())
        .where((line) => line.isNotEmpty)
        .indexed
        .map((e) => PromptItem(text: e.value, index: e.index))
        .toList();

    if (prompts.isEmpty) {
      provider.setIsProcessing(false);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter prompts first')),
      );
      return;
    }

    final output = PipelineService.process(
      prompts: prompts,
      variables: provider.variables,
      splitterEnabled: provider.splitterEnabled,
      wordsPerScene: provider.splitterWordsPerScene,
      styleEnabled: provider.styleEnabled,
      styleText: provider.styleText,
      prefixEnabled: provider.prefixEnabled,
      prefixText: provider.prefixText,
      suffixEnabled: provider.suffixEnabled,
      suffixText: provider.suffixText,
      indexingEnabled: provider.indexingEnabled,
      indexingFormat: provider.indexingFormat,
      customIndexingFormat: provider.customIndexingFormat,
      sliceEnabled: provider.sliceEnabled,
      sliceFrom: provider.sliceFrom,
      sliceTo: provider.sliceTo,
      findReplaceEnabled: provider.findReplaceEnabled,
      findText: provider.findText,
      replaceText: provider.replaceText,
      batchSize: provider.batchSize,
    );

    provider.setLastOutput(output);
    provider.setIsProcessing(false);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Pipeline compiled: ${output.telemetry['totalScenes']} scenes')),
    );
  }
}

class _InputPayloadSection extends StatelessWidget {
  const _InputPayloadSection();

  @override
  Widget build(BuildContext context) {
    return Consumer<PipelineProvider>(
      builder: (context, provider, _) {
        final wordCount = provider.inputText.split(RegExp(r'\s+')).where((w) => w.isNotEmpty).length;
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              maxLines: 8,
              style: const TextStyle(fontFamily: 'JetBrains Mono', fontSize: 13),
              onChanged: provider.setInputText,
              value: provider.inputText,
              decoration: InputDecoration(
                hintText: 'Paste or type your input...',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(4)),
                filled: true,
                fillColor: AppColors.background,
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                ElevatedButton.icon(
                  onPressed: () => provider.setInputText(''),
                  icon: const Icon(Icons.clear, size: 16),
                  label: const Text('Clear'),
                ),
                const SizedBox(width: 8),
                Chip(label: Text('$wordCount words')),
              ],
            ),
          ],
        );
      },
    );
  }
}

class _SceneSplitterSection extends StatelessWidget {
  const _SceneSplitterSection();

  @override
  Widget build(BuildContext context) {
    return Consumer<PipelineProvider>(
      builder: (context, provider, _) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: TextField(
                    keyboardType: TextInputType.number,
                    onChanged: (value) {
                      if (value.isNotEmpty) {
                        provider.setSplitterWordsPerScene(int.parse(value));
                      }
                    },
                    decoration: InputDecoration(
                      labelText: 'Words per scene',
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(4)),
                    ),
                    controller: TextEditingController(
                      text: provider.splitterWordsPerScene.toString(),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                ElevatedButton.icon(
                  onPressed: () {},
                  icon: const Icon(Icons.play_arrow, size: 16),
                  label: const Text('Execute'),
                ),
              ],
            ),
          ],
        );
      },
    );
  }
}

class _EnvironmentVariablesSection extends StatelessWidget {
  const _EnvironmentVariablesSection();

  @override
  Widget build(BuildContext context) {
    return Consumer<PipelineProvider>(
      builder: (context, provider, _) {
        final detectVars = PipelineService.extractVariables(provider.inputText);
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ...provider.variables.entries.map((e) {
              return Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Row(
                  children: [
                    Expanded(
                      child: TextField(
                        readOnly: true,
                        initialValue: e.key,
                        decoration: InputDecoration(
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(4)),
                          labelText: 'Key',
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: TextField(
                        onChanged: (value) {
                          final vars = Map<String, String>.from(provider.variables);
                          vars[e.key] = value;
                          provider.setVariables(vars);
                        },
                        initialValue: e.value,
                        decoration: InputDecoration(
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(4)),
                          labelText: 'Value',
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    IconButton(
                      icon: const Icon(Icons.delete, size: 18),
                      onPressed: () => provider.removeVariable(e.key),
                    ),
                  ],
                ),
              );
            }).toList(),
            ElevatedButton.icon(
              onPressed: () {
                for (final key in detectVars) {
                  if (!provider.variables.containsKey(key)) {
                    provider.addVariable(key, '');
                  }
                }
              },
              icon: const Icon(Icons.search, size: 16),
              label: const Text('Auto-Detect'),
            ),
            const SizedBox(height: 8),
            Chip(label: Text('${provider.variables.length} variables')),
          ],
        );
      },
    );
  }
}

class _FindReplaceSection extends StatelessWidget {
  const _FindReplaceSection();

  @override
  Widget build(BuildContext context) {
    return Consumer<PipelineProvider>(
      builder: (context, provider, _) {
        return Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: TextField(
                    onChanged: provider.setFindText,
                    value: provider.findText,
                    decoration: InputDecoration(
                      labelText: 'Find',
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(4)),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: TextField(
                    onChanged: provider.setReplaceText,
                    value: provider.replaceText,
                    decoration: InputDecoration(
                      labelText: 'Replace',
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(4)),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {},
                child: const Text('Apply Globally'),
              ),
            ),
          ],
        );
      },
    );
  }
}

class _StyleInjectionSection extends StatelessWidget {
  const _StyleInjectionSection();

  @override
  Widget build(BuildContext context) {
    return Consumer2<PipelineProvider, SettingsProvider>(
      builder: (context, pipelineProvider, settingsProvider, _) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            StylePresetManager(
              presets: settingsProvider.stylePresets,
              selectedPresetName: pipelineProvider.activeStylePreset,
              onPresetSelected: (preset) {
                pipelineProvider.setActiveStylePreset(preset.name);
                pipelineProvider.setStyleText(preset.styleText);
              },
              onSaveNewPreset: (name) async {
                final preset = StylePreset(name: name, styleText: pipelineProvider.styleText);
                await settingsProvider.addStylePreset(preset);
              },
              onUpdatePreset: (preset) async {
                await settingsProvider.updateStylePreset(
                  preset.copyWith(styleText: pipelineProvider.styleText),
                );
              },
              onDeletePreset: (id) async {
                await settingsProvider.deleteStylePreset(id);
              },
            ),
            const SizedBox(height: 16),
            TextField(
              maxLines: 4,
              onChanged: pipelineProvider.setStyleText,
              value: pipelineProvider.styleText,
              decoration: InputDecoration(
                hintText: 'Style text...',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(4)),
                filled: true,
                fillColor: AppColors.background,
              ),
            ),
          ],
        );
      },
    );
  }
}

class _PrefixSuffixSection extends StatelessWidget {
  const _PrefixSuffixSection();

  @override
  Widget build(BuildContext context) {
    return Consumer<PipelineProvider>(
      builder: (context, provider, _) {
        return Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: Switch(
                    value: provider.prefixEnabled,
                    onChanged: provider.setPrefixEnabled,
                    activeColor: AppColors.primaryAccent,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  flex: 3,
                  child: TextField(
                    onChanged: provider.setPrefixText,
                    value: provider.prefixText,
                    decoration: InputDecoration(
                      labelText: 'Prefix',
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(4)),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: Switch(
                    value: provider.suffixEnabled,
                    onChanged: provider.setSuffixEnabled,
                    activeColor: AppColors.primaryAccent,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  flex: 3,
                  child: TextField(
                    onChanged: provider.setSuffixText,
                    value: provider.suffixText,
                    decoration: InputDecoration(
                      labelText: 'Suffix',
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(4)),
                    ),
                  ),
                ),
              ],
            ),
          ],
        );
      },
    );
  }
}

class _SceneIndexingSection extends StatelessWidget {
  const _SceneIndexingSection();

  @override
  Widget build(BuildContext context) {
    return Consumer<PipelineProvider>(
      builder: (context, provider, _) {
        return Column(
          children: [
            SegmentedButton<String>(
              segments: const [
                ButtonSegment(label: Text('[Scene 01]'), value: '[Scene 01]'),
                ButtonSegment(label: Text('1.'), value: '1.'),
                ButtonSegment(label: Text('A.'), value: 'A.'),
              ],
              selected: {provider.indexingFormat},
              onSelectionChanged: (value) => provider.setIndexingFormat(value.first),
            ),
            if (provider.indexingFormat == 'Custom')
              Padding(
                padding: const EdgeInsets.only(top: 12),
                child: TextField(
                  onChanged: provider.setCustomIndexingFormat,
                  value: provider.customIndexingFormat,
                  decoration: InputDecoration(
                    labelText: 'Custom format ({index})',
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(4)),
                  ),
                ),
              ),
          ],
        );
      },
    );
  }
}

class _SliceRangeSection extends StatelessWidget {
  const _SliceRangeSection();

  @override
  Widget build(BuildContext context) {
    return Consumer<PipelineProvider>(
      builder: (context, provider, _) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: TextField(
                    keyboardType: TextInputType.number,
                    onChanged: (v) => provider.setSliceFrom(int.tryParse(v) ?? 1),
                    decoration: InputDecoration(
                      labelText: 'From scene #',
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(4)),
                    ),
                    controller: TextEditingController(text: provider.sliceFrom.toString()),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: TextField(
                    keyboardType: TextInputType.number,
                    onChanged: (v) => provider.setSliceTo(int.tryParse(v) ?? -1),
                    decoration: InputDecoration(
                      labelText: 'To scene #',
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(4)),
                    ),
                    controller: TextEditingController(
                      text: provider.sliceTo > 0 ? provider.sliceTo.toString() : '',
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              children: [
                Chip(label: const Text('First 10'), onDeleted: () {}),
                Chip(label: const Text('Last 10'), onDeleted: () {}),
                Chip(label: const Text('Middle 50%'), onDeleted: () {}),
              ],
            ),
          ],
        );
      },
    );
  }
}

class _CompiledOutputSection extends StatelessWidget {
  const _CompiledOutputSection();

  @override
  Widget build(BuildContext context) {
    return Consumer<PipelineProvider>(
      builder: (context, provider, _) {
        if (provider.lastOutput == null) {
          return Center(
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 40),
              child: Text(
                'Compile to see output',
                style: Theme.of(context).textTheme.bodyMedium,
              ),
            ),
          );
        }

        return DefaultTabController(
          length: 3,
          child: Column(
            children: [
              TabBar(
                tabs: const [
                  Tab(text: 'Final Source'),
                  Tab(text: 'Env Applied'),
                  Tab(text: 'Style Applied'),
                ],
                labelColor: AppColors.secondaryAccent,
                unselectedLabelColor: AppColors.textSecondary,
              ),
              SizedBox(
                height: 200,
                child: TabBarView(
                  children: [
                    _OutputTab(text: provider.lastOutput!.finalSource),
                    _OutputTab(text: provider.lastOutput!.envApplied),
                    _OutputTab(text: provider.lastOutput!.styleApplied),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: () {},
                      icon: const Icon(Icons.content_copy, size: 16),
                      label: const Text('Copy All'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () {},
                      icon: const Icon(Icons.download, size: 16),
                      label: const Text('Download'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}

class _OutputTab extends StatelessWidget {
  final String text;

  const _OutputTab({required this.text});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Container(
        padding: const EdgeInsets.all(12),
        color: AppColors.background,
        child: Text(
          text,
          style: const TextStyle(
            fontFamily: 'JetBrains Mono',
            fontSize: 11,
            color: AppColors.textPrimary,
          ),
        ),
      ),
    );
  }
}

class _BatchExportSection extends StatelessWidget {
  const _BatchExportSection();

  @override
  Widget build(BuildContext context) {
    return Consumer<PipelineProvider>(
      builder: (context, provider, _) {
        if (provider.lastOutput == null) return const SizedBox.shrink();

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: TextField(
                    keyboardType: TextInputType.number,
                    onChanged: (v) => provider.setBatchSize(int.tryParse(v) ?? 10),
                    decoration: InputDecoration(
                      labelText: 'Scenes per chunk',
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(4)),
                    ),
                    controller: TextEditingController(text: provider.batchSize.toString()),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            ...provider.lastOutput!.batchChunks.asMap().entries.map((e) {
              return BatchChunkCard(
                chunkIndex: e.key,
                startScene: e.key * provider.batchSize + 1,
                endScene: ((e.key + 1) * provider.batchSize).clamp(0, 9999),
                preview: e.value,
                fullContent: e.value,
              );
            }).toList(),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () {},
                icon: const Icon(Icons.copy_all, size: 16),
                label: const Text('Copy All Chunks'),
              ),
            ),
          ],
        );
      },
    );
  }
}

class _HistorySection extends StatelessWidget {
  const _HistorySection();

  @override
  Widget build(BuildContext context) {
    return Consumer<PipelineProvider>(
      builder: (context, provider, _) {
        if (provider.history.isEmpty) {
          return Center(
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 40),
              child: Column(
                children: [
                  Icon(Icons.history, size: 48, color: AppColors.textSecondary),
                  const SizedBox(height: 12),
                  Text(
                    'No runs yet. Compile to save history.',
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                ],
              ),
            ),
          );
        }

        return Column(
          children: [
            ...provider.history.map((run) {
              return HistoryCard(
                run: run,
                onRestore: () => provider.restoreHistoryRun(run),
              );
            }).toList(),
            const SizedBox(height: 12),
            ElevatedButton.icon(
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (ctx) => AlertDialog(
                    backgroundColor: AppColors.surface,
                    title: const Text('Clear History?'),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(ctx),
                        child: const Text('Cancel'),
                      ),
                      ElevatedButton(
                        onPressed: () {
                          provider.clearHistory();
                          Navigator.pop(ctx);
                        },
                        child: const Text('Clear'),
                      ),
                    ],
                  ),
                );
              },
              icon: const Icon(Icons.delete, size: 16),
              label: const Text('Clear History'),
            ),
          ],
        );
      },
    );
  }
}

class _TelemetrySection extends StatelessWidget {
  const _TelemetrySection();

  @override
  Widget build(BuildContext context) {
    return Consumer<PipelineProvider>(
      builder: (context, provider, _) {
        if (provider.lastOutput == null) return const SizedBox.shrink();

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            StatGrid(telemetry: provider.lastOutput!.telemetry),
            const SizedBox(height: 16),
            Text('Validation Log', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            ...provider.lastOutput!.validationLogs.map((log) {
              final color = log.type == 'success'
                  ? AppColors.success
                  : (log.type == 'warning' ? AppColors.warning : AppColors.error);
              return Container(
                margin: const EdgeInsets.only(bottom: 8),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  border: Border.all(color: color),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Row(
                  children: [
                    Icon(
                      log.type == 'success'
                          ? Icons.check_circle
                          : (log.type == 'warning' ? Icons.warning : Icons.error),
                      color: color,
                      size: 18,
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(log.title, style: Theme.of(context).textTheme.labelMedium),
                          Text(log.message, style: Theme.of(context).textTheme.bodySmall),
                        ],
                      ),
                    ),
                  ],
                ),
              );
            }).toList(),
          ],
        );
      },
    );
  }
}
