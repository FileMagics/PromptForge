import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/style_preset.dart';
import '../models/pipeline_run.dart';

class StorageService {
  static const String keyActiveTab = 'activeTab';
  static const String keyEditorInput = 'editorInput';
  static const String keyPipelineInput = 'pipelineInput';
  static const String keyVariables = 'variables';
  static const String keyStylePresets = 'stylePresets';
  static const String keyActivePreset = 'activePreset';
  static const String keyPrefix = 'prefix';
  static const String keyPrefixEnabled = 'prefixEnabled';
  static const String keySuffix = 'suffix';
  static const String keySuffixEnabled = 'suffixEnabled';
  static const String keyBatchSize = 'batchSize';
  static const String keyIndexingFormat = 'indexingFormat';
  static const String keyPipelineHistory = 'pipelineHistory';
  static const String keySplitterEnabled = 'splitterEnabled';
  static const String keySplitterWordsPerScene = 'splitterWordsPerScene';
  static const String keyStyleEnabled = 'styleEnabled';
  static const String keyIndexingEnabled = 'indexingEnabled';
  static const String keySliceEnabled = 'sliceEnabled';
  static const String keySliceFrom = 'sliceFrom';
  static const String keySliceTo = 'sliceTo';
  static const String keyFindReplace = 'findReplace';
  static const String keyFindReplaceEnabled = 'findReplaceEnabled';

  late SharedPreferences _prefs;

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  // Active Tab
  Future<int> getActiveTab() async => _prefs.getInt(keyActiveTab) ?? 0;

  Future<void> setActiveTab(int index) async {
    await _prefs.setInt(keyActiveTab, index);
  }

  // Editor Input
  Future<String> getEditorInput() async => _prefs.getString(keyEditorInput) ?? '';

  Future<void> setEditorInput(String input) async {
    await _prefs.setString(keyEditorInput, input);
  }

  // Pipeline Input
  Future<String> getPipelineInput() async => _prefs.getString(keyPipelineInput) ?? '';

  Future<void> setPipelineInput(String input) async {
    await _prefs.setString(keyPipelineInput, input);
  }

  // Environment Variables
  Future<Map<String, String>> getVariables() async {
    final jsonStr = _prefs.getString(keyVariables) ?? '{}';
    final Map<String, dynamic> json = jsonDecode(jsonStr);
    return json.cast<String, String>();
  }

  Future<void> setVariables(Map<String, String> variables) async {
    await _prefs.setString(keyVariables, jsonEncode(variables));
  }

  // Style Presets
  Future<List<StylePreset>> getStylePresets() async {
    final jsonStr = _prefs.getString(keyStylePresets);
    if (jsonStr == null) {
      return [StylePreset.defaultPreset()];
    }
    final List<dynamic> json = jsonDecode(jsonStr);
    return json.map((item) => StylePreset.fromJson(item as Map<String, dynamic>)).toList();
  }

  Future<void> setStylePresets(List<StylePreset> presets) async {
    final json = presets.map((p) => p.toJson()).toList();
    await _prefs.setString(keyStylePresets, jsonEncode(json));
  }

  // Active Preset
  Future<String> getActivePreset() async => _prefs.getString(keyActivePreset) ?? 'Noir Cinematic';

  Future<void> setActivePreset(String presetName) async {
    await _prefs.setString(keyActivePreset, presetName);
  }

  // Prefix/Suffix
  Future<String> getPrefix() async => _prefs.getString(keyPrefix) ?? '/imagine prompt:';

  Future<void> setPrefix(String value) async {
    await _prefs.setString(keyPrefix, value);
  }

  Future<bool> isPrefixEnabled() async => _prefs.getBool(keyPrefixEnabled) ?? false;

  Future<void> setPrefixEnabled(bool value) async {
    await _prefs.setBool(keyPrefixEnabled, value);
  }

  Future<String> getSuffix() async => _prefs.getString(keySuffix) ?? '--v 6.0 --ar 16:9';

  Future<void> setSuffix(String value) async {
    await _prefs.setString(keySuffix, value);
  }

  Future<bool> isSuffixEnabled() async => _prefs.getBool(keySuffixEnabled) ?? false;

  Future<void> setSuffixEnabled(bool value) async {
    await _prefs.setBool(keySuffixEnabled, value);
  }

  // Batch Size
  Future<int> getBatchSize() async => _prefs.getInt(keyBatchSize) ?? 10;

  Future<void> setBatchSize(int value) async {
    await _prefs.setInt(keyBatchSize, value);
  }

  // Indexing Format
  Future<String> getIndexingFormat() async => _prefs.getString(keyIndexingFormat) ?? '[Scene 01]';

  Future<void> setIndexingFormat(String value) async {
    await _prefs.setString(keyIndexingFormat, value);
  }

  // Pipeline History
  Future<List<PipelineRun>> getPipelineHistory() async {
    final jsonStr = _prefs.getString(keyPipelineHistory) ?? '[]';
    final List<dynamic> json = jsonDecode(jsonStr);
    return json.map((item) => PipelineRun.fromJson(item as Map<String, dynamic>)).toList();
  }

  Future<void> setPipelineHistory(List<PipelineRun> runs) async {
    final json = runs.map((r) => r.toJson()).toList();
    await _prefs.setString(keyPipelineHistory, jsonEncode(json));
  }

  Future<void> addPipelineRun(PipelineRun run) async {
    final history = await getPipelineHistory();
    history.insert(0, run);
    if (history.length > 20) {
      history.removeRange(20, history.length);
    }
    await setPipelineHistory(history);
  }

  // Toggle States
  Future<bool> isSplitterEnabled() async => _prefs.getBool(keySplitterEnabled) ?? false;

  Future<void> setSplitterEnabled(bool value) async {
    await _prefs.setBool(keySplitterEnabled, value);
  }

  Future<int> getSplitterWordsPerScene() async => _prefs.getInt(keySplitterWordsPerScene) ?? 20;

  Future<void> setSplitterWordsPerScene(int value) async {
    await _prefs.setInt(keySplitterWordsPerScene, value);
  }

  Future<bool> isStyleEnabled() async => _prefs.getBool(keyStyleEnabled) ?? true;

  Future<void> setStyleEnabled(bool value) async {
    await _prefs.setBool(keyStyleEnabled, value);
  }

  Future<bool> isIndexingEnabled() async => _prefs.getBool(keyIndexingEnabled) ?? false;

  Future<void> setIndexingEnabled(bool value) async {
    await _prefs.setBool(keyIndexingEnabled, value);
  }

  Future<bool> isSliceEnabled() async => _prefs.getBool(keySliceEnabled) ?? false;

  Future<void> setSliceEnabled(bool value) async {
    await _prefs.setBool(keySliceEnabled, value);
  }

  Future<int> getSliceFrom() async => _prefs.getInt(keySliceFrom) ?? 1;

  Future<void> setSliceFrom(int value) async {
    await _prefs.setInt(keySliceFrom, value);
  }

  Future<int> getSliceTo() async => _prefs.getInt(keySliceTo) ?? -1;

  Future<void> setSliceTo(int value) async {
    await _prefs.setInt(keySliceTo, value);
  }

  Future<bool> isFindReplaceEnabled() async => _prefs.getBool(keyFindReplaceEnabled) ?? false;

  Future<void> setFindReplaceEnabled(bool value) async {
    await _prefs.setBool(keyFindReplaceEnabled, value);
  }

  Future<Map<String, String>> getFindReplace() async {
    final jsonStr = _prefs.getString(keyFindReplace) ?? '{"find":"","replace":""}';
    final Map<String, dynamic> json = jsonDecode(jsonStr);
    return json.cast<String, String>();
  }

  Future<void> setFindReplace(Map<String, String> findReplace) async {
    await _prefs.setString(keyFindReplace, jsonEncode(findReplace));
  }

  // Clear All
  Future<void> clearAll() async {
    await _prefs.clear();
  }
}
