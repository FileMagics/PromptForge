import '../models/prompt_item.dart';

class ParseResult {
  final List<PromptItem> prompts;
  final String detectedFormat;
  final int totalWords;

  ParseResult({
    required this.prompts,
    required this.detectedFormat,
    required this.totalWords,
  });
}

class ParserService {
  static const String formatBlankLine = 'Blank Line Separated';
  static const String formatNumbered = 'Numbered (1., 1), 01.)';
  static const String formatLettered = 'Lettered (A., A))';
  static const String formatSceneTags = 'Scene Tags ([Scene], Scene:, ##)';
  static const String formatCustom = 'Custom Delimiter';
  static const String formatUnknown = 'Unknown';

  static ParseResult parse(String input, {String? customDelimiter}) {
    if (input.trim().isEmpty) {
      return ParseResult(
        prompts: [],
        detectedFormat: formatUnknown,
        totalWords: 0,
      );
    }

    // Try each format in order
    final blankLineResult = _tryBlankLineFormat(input);
    if (blankLineResult.prompts.isNotEmpty) {
      return blankLineResult;
    }

    final numberedResult = _tryNumberedFormat(input);
    if (numberedResult.prompts.isNotEmpty) {
      return numberedResult;
    }

    final letteredResult = _tryLetteredFormat(input);
    if (letteredResult.prompts.isNotEmpty) {
      return letteredResult;
    }

    final sceneTagResult = _trySceneTagFormat(input);
    if (sceneTagResult.prompts.isNotEmpty) {
      return sceneTagResult;
    }

    if (customDelimiter != null && customDelimiter.isNotEmpty) {
      final customResult = _tryCustomDelimiter(input, customDelimiter);
      if (customResult.prompts.isNotEmpty) {
        return customResult;
      }
    }

    // Fallback: treat entire input as single prompt
    return ParseResult(
      prompts: [PromptItem(text: input.trim(), index: 0)],
      detectedFormat: formatUnknown,
      totalWords: _countWords(input),
    );
  }

  static ParseResult _tryBlankLineFormat(String input) {
    final parts = input.split(RegExp(r'\n\s*\n+'));
    final prompts = parts
        .map((p) => p.trim())
        .where((p) => p.isNotEmpty)
        .indexed
        .map((e) => PromptItem(text: e.value, index: e.index))
        .toList();

    if (prompts.isEmpty) {
      return ParseResult(prompts: [], detectedFormat: '', totalWords: 0);
    }

    final totalWords = prompts.fold<int>(0, (sum, p) => sum + p.wordCount);
    return ParseResult(
      prompts: prompts,
      detectedFormat: formatBlankLine,
      totalWords: totalWords,
    );
  }

  static ParseResult _tryNumberedFormat(String input) {
    final lines = input.split('\n');
    final prompts = <PromptItem>[];
    int index = 0;

    for (final line in lines) {
      final trimmed = line.trim();
      if (trimmed.isEmpty) continue;

      // Match patterns: 1., 1), 01., 01)
      final match = RegExp(r'^(\d+[\.\)])?\s*(.+)$').firstMatch(trimmed);
      if (match != null && match.group(2) != null) {
        final text = match.group(2)!.trim();
        if (text.isNotEmpty) {
          prompts.add(PromptItem(text: text, index: index));
          index++;
        }
      }
    }

    if (prompts.isEmpty) {
      return ParseResult(prompts: [], detectedFormat: '', totalWords: 0);
    }

    final totalWords = prompts.fold<int>(0, (sum, p) => sum + p.wordCount);
    return ParseResult(
      prompts: prompts,
      detectedFormat: formatNumbered,
      totalWords: totalWords,
    );
  }

  static ParseResult _tryLetteredFormat(String input) {
    final lines = input.split('\n');
    final prompts = <PromptItem>[];
    int index = 0;

    for (final line in lines) {
      final trimmed = line.trim();
      if (trimmed.isEmpty) continue;

      // Match patterns: A., A), a., a)
      final match = RegExp(r'^([A-Za-z][\.\)])?\s*(.+)$').firstMatch(trimmed);
      if (match != null && match.group(2) != null) {
        final prefix = match.group(1);
        if (prefix != null && prefix.length <= 2) {
          final text = match.group(2)!.trim();
          if (text.isNotEmpty) {
            prompts.add(PromptItem(text: text, index: index));
            index++;
          }
        }
      }
    }

    if (prompts.isEmpty) {
      return ParseResult(prompts: [], detectedFormat: '', totalWords: 0);
    }

    final totalWords = prompts.fold<int>(0, (sum, p) => sum + p.wordCount);
    return ParseResult(
      prompts: prompts,
      detectedFormat: formatLettered,
      totalWords: totalWords,
    );
  }

  static ParseResult _trySceneTagFormat(String input) {
    final lines = input.split('\n');
    final prompts = <PromptItem>[];
    int index = 0;
    String? currentText;

    for (final line in lines) {
      final trimmed = line.trim();

      // Match [Scene X], Scene X:, ## Scene X, etc.
      if (RegExp(r'^\[?[Ss]cene\s+\d+\]?|^#{2,}\s+[Ss]cene').hasMatch(trimmed)) {
        if (currentText != null && currentText.isNotEmpty) {
          prompts.add(PromptItem(text: currentText.trim(), index: index));
          index++;
        }
        currentText = '';
      } else if (trimmed.isNotEmpty) {
        currentText = (currentText ?? '') + (currentText != null ? '\n' : '') + trimmed;
      }
    }

    if (currentText != null && currentText.isNotEmpty) {
      prompts.add(PromptItem(text: currentText.trim(), index: index));
    }

    if (prompts.isEmpty) {
      return ParseResult(prompts: [], detectedFormat: '', totalWords: 0);
    }

    final totalWords = prompts.fold<int>(0, (sum, p) => sum + p.wordCount);
    return ParseResult(
      prompts: prompts,
      detectedFormat: formatSceneTags,
      totalWords: totalWords,
    );
  }

  static ParseResult _tryCustomDelimiter(String input, String delimiter) {
    final parts = input.split(RegExp(RegExp.escape(delimiter)));
    final prompts = parts
        .map((p) => p.trim())
        .where((p) => p.isNotEmpty)
        .indexed
        .map((e) => PromptItem(text: e.value, index: e.index))
        .toList();

    if (prompts.isEmpty) {
      return ParseResult(prompts: [], detectedFormat: '', totalWords: 0);
    }

    final totalWords = prompts.fold<int>(0, (sum, p) => sum + p.wordCount);
    return ParseResult(
      prompts: prompts,
      detectedFormat: '$formatCustom: "$delimiter"',
      totalWords: totalWords,
    );
  }

  static int _countWords(String text) {
    return text.split(RegExp(r'\s+')).where((word) => word.isNotEmpty).length;
  }

  static String formatPrompts(
    List<PromptItem> prompts, {
    required String format,
    String customFormat = '',
  }) {
    if (prompts.isEmpty) return '';

    switch (format) {
      case '[Scene 01]':
        return prompts
            .map((p) => '[Scene ${(p.index + 1).toString().padLeft(2, '0')}]\n${p.text}')
            .join('\n\n');
      case '1.':
        return prompts.map((p) => '${p.index + 1}. ${p.text}').join('\n\n');
      case 'A.':
        return prompts.map((p) => '${String.fromCharCode(65 + p.index)}. ${p.text}').join('\n\n');
      case 'Custom':
        return prompts
            .map((p) => customFormat.replaceAll('{index}', (p.index + 1).toString()) + p.text)
            .join('\n\n');
      default:
        return prompts.map((p) => p.text).join('\n\n');
    }
  }
}
