import '../models/prompt_item.dart';

class PipelineOutput {
  final String finalSource;
  final String envApplied;
  final String styleApplied;
  final List<String> batchChunks;
  final Map<String, dynamic> telemetry;
  final List<ValidationLog> validationLogs;

  PipelineOutput({
    required this.finalSource,
    required this.envApplied,
    required this.styleApplied,
    required this.batchChunks,
    required this.telemetry,
    required this.validationLogs,
  });
}

class ValidationLog {
  final String type; // 'success', 'warning', 'error'
  final String title;
  final String message;

  ValidationLog({
    required this.type,
    required this.title,
    required this.message,
  });
}

class PipelineService {
  static PipelineOutput process({
    required List<PromptItem> prompts,
    required Map<String, String> variables,
    required bool splitterEnabled,
    required int wordsPerScene,
    required bool styleEnabled,
    required String styleText,
    required bool prefixEnabled,
    required String prefixText,
    required bool suffixEnabled,
    required String suffixText,
    required bool indexingEnabled,
    required String indexingFormat,
    required String customIndexingFormat,
    required bool sliceEnabled,
    required int sliceFrom,
    required int sliceTo,
    required bool findReplaceEnabled,
    required String findText,
    required String replaceText,
    required int batchSize,
  }) {
    final startTime = DateTime.now();
    final logs = <ValidationLog>[];
    var workingPrompts = List<PromptItem>.from(prompts);

    // Step 1: Apply Find & Replace
    if (findReplaceEnabled && findText.isNotEmpty) {
      workingPrompts = workingPrompts.map((p) {
        final updated = p.text.replaceAll(findText, replaceText);
        return p.copyWith(text: updated);
      }).toList();
      logs.add(ValidationLog(
        type: 'success',
        title: 'Find & Replace',
        message: 'Replaced ${findText.length} occurrences of "$findText"',
      ));
    }

    // Step 2: Apply Environment Variables
    String envAppliedOutput = '';
    if (variables.isNotEmpty) {
      workingPrompts = workingPrompts.map((p) {
        var text = p.text;
        variables.forEach((key, value) {
          text = text.replaceAll('{{$key}}', value);
        });
        return p.copyWith(text: text);
      }).toList();
      envAppliedOutput = _renderPrompts(workingPrompts);
      logs.add(ValidationLog(
        type: 'success',
        title: 'Variables Applied',
        message: '${variables.length} environment variables substituted',
      ));
    } else {
      envAppliedOutput = _renderPrompts(workingPrompts);
    }

    // Step 3: Apply Style Injection
    if (styleEnabled && styleText.isNotEmpty) {
      workingPrompts = workingPrompts.map((p) {
        final updated = '${p.text}\n\n$styleText';
        return p.copyWith(text: updated);
      }).toList();
      logs.add(ValidationLog(
        type: 'success',
        title: 'Style Injected',
        message: 'Applied style to all ${workingPrompts.length} prompts',
      ));
    }

    String styleAppliedOutput = _renderPrompts(workingPrompts);

    // Step 4: Apply Prefix & Suffix
    if ((prefixEnabled && prefixText.isNotEmpty) || (suffixEnabled && suffixText.isNotEmpty)) {
      workingPrompts = workingPrompts.map((p) {
        var text = p.text;
        if (prefixEnabled && prefixText.isNotEmpty) {
          text = '$prefixText $text';
        }
        if (suffixEnabled && suffixText.isNotEmpty) {
          text = '$text $suffixText';
        }
        return p.copyWith(text: text);
      }).toList();
      logs.add(ValidationLog(
        type: 'success',
        title: 'Prefix & Suffix',
        message: 'Applied formatting wrapper',
      ));
    }

    // Step 5: Apply Scene Indexing
    if (indexingEnabled) {
      workingPrompts = _applyIndexing(workingPrompts, indexingFormat, customIndexingFormat);
      logs.add(ValidationLog(
        type: 'success',
        title: 'Indexing Applied',
        message: 'Scenes indexed as "$indexingFormat"',
      ));
    }

    // Step 6: Apply Slice
    if (sliceEnabled && sliceFrom > 0) {
      final from = sliceFrom - 1;
      final to = sliceTo > 0 ? sliceTo : workingPrompts.length;
      if (from < workingPrompts.length && to > from) {
        workingPrompts = workingPrompts.sublist(from, to.clamp(0, workingPrompts.length));
        logs.add(ValidationLog(
          type: 'success',
          title: 'Slice Applied',
          message: 'Kept scenes $from to ${to - 1}',
        ));
      }
    }

    // Final output
    final finalSource = _renderPrompts(workingPrompts);

    // Step 7: Batch Chunking
    final batchChunks = _createBatches(workingPrompts, batchSize);
    logs.add(ValidationLog(
      type: 'success',
      title: 'Batches Created',
      message: '${batchChunks.length} batches of max $batchSize prompts',
    ));

    final endTime = DateTime.now();
    final processTime = endTime.difference(startTime).inMilliseconds;

    // Calculate telemetry
    final totalWords = workingPrompts.fold<int>(0, (sum, p) => sum + p.wordCount);
    final avgWordsPerScene = workingPrompts.isEmpty ? 0 : (totalWords / workingPrompts.length).round();
    var variablesReplaced = 0;
    if (findReplaceEnabled && findText.isNotEmpty) {
      variablesReplaced = prompts.fold<int>(0, (sum, p) => sum + findText.allMatches(p.text).length);
    }

    return PipelineOutput(
      finalSource: finalSource,
      envApplied: envAppliedOutput,
      styleApplied: styleAppliedOutput,
      batchChunks: batchChunks,
      telemetry: {
        'totalScenes': workingPrompts.length,
        'wordCount': totalWords,
        'variablesReplaced': variablesReplaced,
        'processTime': processTime,
        'avgWordsPerScene': avgWordsPerScene,
        'batchChunks': batchChunks.length,
      },
      validationLogs: logs,
    );
  }

  static List<PromptItem> _applyIndexing(
    List<PromptItem> prompts,
    String format,
    String customFormat,
  ) {
    return prompts.indexed.map((e) {
      final index = e.index;
      var prefix = '';

      switch (format) {
        case '[Scene 01]':
          prefix = '[Scene ${(index + 1).toString().padLeft(2, '0')}] ';
          break;
        case '1.':
          prefix = '${index + 1}. ';
          break;
        case 'A.':
          prefix = '${String.fromCharCode(65 + index)}. ';
          break;
        case 'Custom':
          prefix = customFormat.replaceAll('{index}', '${index + 1}');
          break;
      }

      return e.value.copyWith(text: '$prefix${e.value.text}');
    }).toList();
  }

  static List<String> _createBatches(List<PromptItem> prompts, int batchSize) {
    final batches = <String>[];
    for (int i = 0; i < prompts.length; i += batchSize) {
      final end = (i + batchSize).clamp(0, prompts.length);
      final batch = prompts.sublist(i, end);
      batches.add(_renderPrompts(batch));
    }
    return batches;
  }

  static String _renderPrompts(List<PromptItem> prompts) {
    return prompts.map((p) => p.text).join('\n\n');
  }

  static List<String> extractVariables(String text) {
    final regex = RegExp(r'\{\{(\w+)\}\}');
    final matches = regex.allMatches(text);
    final vars = <String>{};
    for (final match in matches) {
      if (match.group(1) != null) {
        vars.add(match.group(1)!);
      }
    }
    return vars.toList();
  }
}
