import 'package:flutter/material.dart';
import '../models/style_preset.dart';
import '../theme/app_theme.dart';

class StylePresetManager extends StatefulWidget {
  final List<StylePreset> presets;
  final String selectedPresetName;
  final Function(StylePreset) onPresetSelected;
  final Function(String) onSaveNewPreset;
  final Function(StylePreset) onUpdatePreset;
  final Function(String) onDeletePreset;

  const StylePresetManager({
    required this.presets,
    required this.selectedPresetName,
    required this.onPresetSelected,
    required this.onSaveNewPreset,
    required this.onUpdatePreset,
    required this.onDeletePreset,
    Key? key,
  }) : super(key: key);

  @override
  State<StylePresetManager> createState() => _StylePresetManagerState();
}

class _StylePresetManagerState extends State<StylePresetManager> {
  late TextEditingController _newPresetController;

  @override
  void initState() {
    super.initState();
    _newPresetController = TextEditingController();
  }

  @override
  void dispose() {
    _newPresetController.dispose();
    super.dispose();
  }

  void _showSavePresetDialog() {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          backgroundColor: AppColors.surface,
          title: Text(
            'Save as New Preset',
            style: Theme.of(context).textTheme.titleMedium,
          ),
          content: TextField(
            controller: _newPresetController,
            style: const TextStyle(color: AppColors.textPrimary),
            decoration: InputDecoration(
              hintText: 'Preset name',
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(4),
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                if (_newPresetController.text.isNotEmpty) {
                  widget.onSaveNewPreset(_newPresetController.text);
                  _newPresetController.clear();
                  Navigator.pop(context);
                }
              },
              child: const Text('Save'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        DropdownButton<String>(
          value: widget.selectedPresetName,
          isExpanded: true,
          dropdownColor: AppColors.surface,
          style: const TextStyle(color: AppColors.textPrimary),
          items: widget.presets
              .map((preset) => DropdownMenuItem(
                    value: preset.name,
                    child: Text(preset.name),
                  ))
              .toList(),
          onChanged: (value) {
            if (value != null) {
              final preset = widget.presets.firstWhere((p) => p.name == value);
              widget.onPresetSelected(preset);
            }
          },
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: _showSavePresetDialog,
                icon: const Icon(Icons.add, size: 16),
                label: const Text('Save as New'),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: OutlinedButton.icon(
                onPressed: () {
                  final selected = widget.presets
                      .firstWhereOrNull((p) => p.name == widget.selectedPresetName);
                  if (selected != null) {
                    showDialog(
                      context: context,
                      builder: (context) => AlertDialog(
                        backgroundColor: AppColors.surface,
                        title: const Text('Update Preset?'),
                        content: Text('Update "${selected.name}" with current settings?'),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.pop(context),
                            child: const Text('Cancel'),
                          ),
                          ElevatedButton(
                            onPressed: () {
                              widget.onUpdatePreset(selected);
                              Navigator.pop(context);
                            },
                            child: const Text('Update'),
                          ),
                        ],
                      ),
                    );
                  }
                },
                icon: const Icon(Icons.edit, size: 16),
                label: const Text('Update'),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: OutlinedButton.icon(
                onPressed: () {
                  final selected = widget.presets
                      .firstWhereOrNull((p) => p.name == widget.selectedPresetName);
                  if (selected != null) {
                    showDialog(
                      context: context,
                      builder: (context) => AlertDialog(
                        backgroundColor: AppColors.surface,
                        title: const Text('Delete Preset?'),
                        content: Text('Delete "${selected.name}"?'),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.pop(context),
                            child: const Text('Cancel'),
                          ),
                          ElevatedButton(
                            onPressed: () {
                              widget.onDeletePreset(selected.id);
                              Navigator.pop(context);
                            },
                            child: const Text('Delete'),
                          ),
                        ],
                      ),
                    );
                  }
                },
                icon: const Icon(Icons.delete, size: 16),
                label: const Text('Delete'),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

extension _FirstWhereOrNull<T> on List<T> {
  T? firstWhereOrNull(bool Function(T) test) {
    try {
      return firstWhere(test);
    } catch (e) {
      return null;
    }
  }
}
