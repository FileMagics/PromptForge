import 'package:flutter/material.dart';
import '../models/prompt_item.dart';
import '../theme/app_theme.dart';

class PromptCard extends StatefulWidget {
  final PromptItem prompt;
  final int index;
  final bool selectionMode;
  final VoidCallback onDelete;
  final Function(String) onTextChanged;
  final VoidCallback onToggleSelection;
  final ReorderableDelayedDragStartListener? dragStartListener;

  const PromptCard({
    required this.prompt,
    required this.index,
    required this.selectionMode,
    required this.onDelete,
    required this.onTextChanged,
    required this.onToggleSelection,
    this.dragStartListener,
    Key? key,
  }) : super(key: key);

  @override
  State<PromptCard> createState() => _PromptCardState();
}

class _PromptCardState extends State<PromptCard> {
  late TextEditingController _controller;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: widget.prompt.text);
  }

  @override
  void didUpdateWidget(PromptCard oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.prompt.text != widget.prompt.text) {
      _controller.text = widget.prompt.text;
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final wordCount = widget.prompt.wordCount;

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: AppColors.surface,
        border: Border(
          left: BorderSide(
            color: widget.selectionMode && widget.prompt.isSelected
                ? AppColors.primaryAccent
                : AppColors.borderColor,
            width: 3,
          ),
        ),
        boxShadow: [AppTheme.mediumDropShadow],
      ),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                if (widget.selectionMode)
                  Padding(
                    padding: const EdgeInsets.only(right: 12),
                    child: Checkbox(
                      value: widget.prompt.isSelected,
                      onChanged: (_) => widget.onToggleSelection(),
                      fillColor: MaterialStateProperty.all(AppColors.primaryAccent),
                      checkColor: AppColors.secondaryAccent,
                    ),
                  ),
                Text(
                  widget.index.toString().padLeft(2, '0'),
                  style: const TextStyle(
                    fontFamily: 'JetBrains Mono',
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: AppColors.secondaryAccent,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Text(
                    'Prompt ${widget.index + 1}',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                ),
                Chip(
                  label: Text(
                    '$wordCount words',
                    style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w500),
                  ),
                  backgroundColor: AppColors.idle,
                  side: BorderSide.none,
                ),
              ],
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _controller,
              maxLines: 4,
              style: const TextStyle(
                fontFamily: 'JetBrains Mono',
                fontSize: 13,
                color: AppColors.textPrimary,
              ),
              onChanged: widget.onTextChanged,
              decoration: InputDecoration(
                hintText: 'Enter prompt text...',
                hintStyle: const TextStyle(color: AppColors.textSecondary),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(4),
                  borderSide: const BorderSide(color: AppColors.borderColor),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(4),
                  borderSide: const BorderSide(color: AppColors.borderColor),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(4),
                  borderSide: const BorderSide(color: AppColors.primaryAccent, width: 2),
                ),
                filled: true,
                fillColor: AppColors.background,
                contentPadding: const EdgeInsets.all(12),
              ),
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                IconButton(
                  icon: const Icon(Icons.content_copy, size: 18),
                  onPressed: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Copied prompt ${widget.index + 1}')),
                    );
                  },
                  tooltip: 'Copy',
                ),
                IconButton(
                  icon: const Icon(Icons.delete_outline, size: 18),
                  onPressed: widget.onDelete,
                  tooltip: 'Delete',
                ),
                if (widget.dragStartListener != null)
                  widget.dragStartListener!(
                    ReorderableDelayedDragStartListener(
                      key: ValueKey(widget.prompt.id),
                      index: widget.index,
                      child: IconButton(
                        icon: const Icon(Icons.drag_handle, size: 18),
                        onPressed: () {},
                        tooltip: 'Drag to reorder',
                      ),
                    ),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
