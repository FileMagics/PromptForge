import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class BatchChunkCard extends StatelessWidget {
  final int chunkIndex;
  final int startScene;
  final int endScene;
  final String preview;
  final String fullContent;

  const BatchChunkCard({
    required this.chunkIndex,
    required this.startScene,
    required this.endScene,
    required this.preview,
    required this.fullContent,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: AppColors.surface,
        border: Border(
          left: BorderSide(color: AppColors.primaryAccent, width: 3),
        ),
        boxShadow: [AppTheme.mediumDropShadow],
      ),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Chunk ${chunkIndex + 1}',
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          color: AppColors.secondaryAccent,
                        ),
                      ),
                      Text(
                        '(Scenes $startScene–$endScene)',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ],
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.content_copy, size: 18),
                  onPressed: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Copied Chunk ${chunkIndex + 1}')),
                    );
                  },
                  tooltip: 'Copy',
                ),
              ],
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppColors.background,
                border: Border.all(color: AppColors.borderColor),
                borderRadius: BorderRadius.circular(4),
              ),
              child: Text(
                preview.length > 100 ? '${preview.substring(0, 100)}...' : preview,
                style: const TextStyle(
                  fontFamily: 'JetBrains Mono',
                  fontSize: 12,
                  color: AppColors.textSecondary,
                  height: 1.5,
                ),
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
