import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class StatGrid extends StatelessWidget {
  final Map<String, dynamic> telemetry;

  const StatGrid({required this.telemetry, Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final stats = [
      ('Total Scenes', telemetry['totalScenes'] ?? 0),
      ('Word Count', telemetry['wordCount'] ?? 0),
      ('Variables Replaced', telemetry['variablesReplaced'] ?? 0),
      ('Process Time (ms)', telemetry['processTime'] ?? 0),
      ('Avg Words/Scene', telemetry['avgWordsPerScene'] ?? 0),
      ('Batch Chunks', telemetry['batchChunks'] ?? 0),
    ];

    return GridView.count(
      crossAxisCount: 3,
      childAspectRatio: 1.5,
      mainAxisSpacing: 12,
      crossAxisSpacing: 12,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      children: stats.map((stat) {
        return Container(
          decoration: BoxDecoration(
            color: AppColors.surface,
            border: Border(
              left: BorderSide(color: AppColors.primaryAccent, width: 3),
            ),
            boxShadow: [AppTheme.mediumDropShadow],
          ),
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                stat.$2.toString(),
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  color: AppColors.secondaryAccent,
                  fontFamily: 'JetBrains Mono',
                ),
              ),
              const SizedBox(height: 8),
              Text(
                stat.$1,
                style: Theme.of(context).textTheme.labelSmall?.copyWith(
                  color: AppColors.textSecondary,
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        );
      }).toList(),
    );
  }
}
