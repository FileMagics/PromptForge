import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class PipelineVisualizer extends StatefulWidget {
  final int activeStep;
  final int completedSteps;

  const PipelineVisualizer({
    required this.activeStep,
    required this.completedSteps,
    Key? key,
  }) : super(key: key);

  @override
  State<PipelineVisualizer> createState() => _PipelineVisualizerState();
}

class _PipelineVisualizerState extends State<PipelineVisualizer>
    with SingleTickerProviderStateMixin {
  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    )..repeat();
    _pulseAnimation = Tween<double>(begin: 1.0, end: 1.3).animate(_pulseController);
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    const steps = [
      'Input',
      'Split',
      'F&R',
      'ENV',
      'Prefix',
      'Style',
      'Index',
      'Slice',
      'Output',
    ];

    return Container(
      color: AppColors.surface,
      padding: const EdgeInsets.all(16),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: [
            for (int i = 0; i < steps.length; i++) ...[
              Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  AnimatedBuilder(
                    animation: _pulseAnimation,
                    builder: (context, child) {
                      return Container(
                        width: i == widget.activeStep ? 44 * _pulseAnimation.value : 44,
                        height: i == widget.activeStep ? 44 * _pulseAnimation.value : 44,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: i < widget.completedSteps
                              ? AppColors.success
                              : (i == widget.activeStep
                                  ? AppColors.primaryAccent
                                  : AppColors.idle),
                          boxShadow: i == widget.activeStep
                              ? [
                                  BoxShadow(
                                    color: AppColors.primaryAccent.withOpacity(0.5),
                                    blurRadius: 12,
                                    spreadRadius: 2,
                                  )
                                ]
                              : [],
                        ),
                        child: Center(
                          child: i < widget.completedSteps
                              ? const Icon(
                                  Icons.check,
                                  color: AppColors.secondaryAccent,
                                  size: 20,
                                )
                              : Text(
                                  '${i + 1}',
                                  style: const TextStyle(
                                    color: AppColors.secondaryAccent,
                                    fontWeight: FontWeight.w700,
                                    fontSize: 14,
                                  ),
                                ),
                        ),
                      );
                    },
                  ),
                  const SizedBox(height: 8),
                  Text(
                    steps[i],
                    style: Theme.of(context).textTheme.labelSmall,
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
              if (i < steps.length - 1)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 16),
                  child: Container(
                    width: 40,
                    height: 2,
                    color: i < widget.completedSteps
                        ? AppColors.secondaryAccent
                        : AppColors.borderColor,
                  ),
                ),
            ],
          ],
        ),
      ),
    );
  }
}
