import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class SectionCard extends StatelessWidget {
  final String title;
  final IconData icon;
  final Widget content;
  final bool enabled;
  final ValueChanged<bool>? onEnabledChanged;
  final bool initiallyExpanded;

  const SectionCard({
    required this.title,
    required this.icon,
    required this.content,
    this.enabled = true,
    this.onEnabledChanged,
    this.initiallyExpanded = true,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: AppColors.surface,
        border: Border(
          left: BorderSide(
            color: AppColors.primaryAccent,
            width: 3,
          ),
        ),
        boxShadow: [AppTheme.mediumDropShadow],
      ),
      child: Theme(
        data: Theme.of(context).copyWith(
          dividerColor: Colors.transparent,
        ),
        child: ExpansionTile(
          initiallyExpanded: initiallyExpanded,
          leading: Icon(
            icon,
            color: AppColors.primaryAccent,
            size: 20,
          ),
          title: Text(
            title,
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
              color: AppColors.textPrimary,
            ),
          ),
          trailing: Padding(
            padding: const EdgeInsets.only(right: 12),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (onEnabledChanged != null)
                  Container(
                    decoration: BoxDecoration(
                      color: enabled ? AppColors.primaryAccent : AppColors.idle,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    child: Text(
                      enabled ? 'ON' : 'OFF',
                      style: const TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                        color: AppColors.textPrimary,
                      ),
                    ),
                  ),
                const SizedBox(width: 12),
                const Icon(Icons.expand_more, color: AppColors.textSecondary),
              ],
            ),
          ),
          onExpansionChanged: (isExpanded) {
            if (onEnabledChanged != null && isExpanded) {
              onEnabledChanged!(true);
            }
          },
          collapsedBackgroundColor: AppColors.surface,
          backgroundColor: AppColors.surface,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (onEnabledChanged != null)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 16),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(
                              'Enable this section',
                              style: Theme.of(context).textTheme.bodyMedium,
                            ),
                          ),
                          Switch(
                            value: enabled,
                            onChanged: onEnabledChanged,
                            activeColor: AppColors.primaryAccent,
                          ),
                        ],
                      ),
                    ),
                  content,
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
