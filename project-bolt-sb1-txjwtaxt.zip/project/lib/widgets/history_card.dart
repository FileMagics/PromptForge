import 'package:flutter/material.dart';
import '../models/pipeline_run.dart';
import '../theme/app_theme.dart';

class HistoryCard extends StatelessWidget {
  final PipelineRun run;
  final VoidCallback onRestore;

  const HistoryCard({
    required this.run,
    required this.onRestore,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: AppColors.surface,
        border: Border(
          left: BorderSide(color: AppColors.primaryAccent, width: 3),
        ),
        boxShadow: [AppTheme.mediumDropShadow],
      ),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        run.presetName,
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          color: AppColors.secondaryAccent,
                        ),
                      ),
                      Text(
                        '${run.sceneCount} scenes • ${run.timestamp.toString().split('.')[0]}',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ],
                  ),
                ),
                ElevatedButton.icon(
                  onPressed: onRestore,
                  icon: const Icon(Icons.restore, size: 16),
                  label: const Text('Restore'),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppColors.background,
                border: Border.all(color: AppColors.borderColor),
                borderRadius: BorderRadius.circular(4),
              ),
              child: Text(
                run.inputPreview.length > 120
                    ? '${run.inputPreview.substring(0, 120)}...'
                    : run.inputPreview,
                style: const TextStyle(
                  fontFamily: 'JetBrains Mono',
                  fontSize: 12,
                  color: AppColors.textSecondary,
                  height: 1.5,
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
