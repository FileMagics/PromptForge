import 'package:flutter/material.dart';
import '../models/pipeline_run.dart';
import '../services/pipeline_service.dart';

class PipelineProvider extends ChangeNotifier {
  String inputText = '';
  Map<String, String> variables = {};
  bool splitterEnabled = false;
  int splitterWordsPerScene = 20;
  bool styleEnabled = true;
  bool prefixEnabled = false;
  String prefixText = '/imagine prompt:';
  bool suffixEnabled = false;
  String suffixText = '--v 6.0 --ar 16:9';
  bool indexingEnabled = false;
  String indexingFormat = '[Scene 01]';
  String customIndexingFormat = '';
  bool sliceEnabled = false;
  int sliceFrom = 1;
  int sliceTo = -1;
  bool findReplaceEnabled = false;
  String findText = '';
  String replaceText = '';
  int batchSize = 10;
  String activeStylePreset = 'Noir Cinematic';
  String styleText = '';

  PipelineOutput? lastOutput;
  List<PipelineRun> history = [];
  bool isProcessing = false;

  void setInputText(String text) {
    inputText = text;
    notifyListeners();
  }

  void setVariables(Map<String, String> vars) {
    variables = vars;
    notifyListeners();
  }

  void addVariable(String key, String value) {
    variables[key] = value;
    notifyListeners();
  }

  void removeVariable(String key) {
    variables.remove(key);
    notifyListeners();
  }

  void setSplitterEnabled(bool value) {
    splitterEnabled = value;
    notifyListeners();
  }

  void setSplitterWordsPerScene(int value) {
    splitterWordsPerScene = value;
    notifyListeners();
  }

  void setStyleEnabled(bool value) {
    styleEnabled = value;
    notifyListeners();
  }

  void setStyleText(String text) {
    styleText = text;
    notifyListeners();
  }

  void setActiveStylePreset(String presetName) {
    activeStylePreset = presetName;
    notifyListeners();
  }

  void setPrefixEnabled(bool value) {
    prefixEnabled = value;
    notifyListeners();
  }

  void setPrefixText(String text) {
    prefixText = text;
    notifyListeners();
  }

  void setSuffixEnabled(bool value) {
    suffixEnabled = value;
    notifyListeners();
  }

  void setSuffixText(String text) {
    suffixText = text;
    notifyListeners();
  }

  void setIndexingEnabled(bool value) {
    indexingEnabled = value;
    notifyListeners();
  }

  void setIndexingFormat(String format) {
    indexingFormat = format;
    notifyListeners();
  }

  void setCustomIndexingFormat(String format) {
    customIndexingFormat = format;
    notifyListeners();
  }

  void setSliceEnabled(bool value) {
    sliceEnabled = value;
    notifyListeners();
  }

  void setSliceFrom(int value) {
    sliceFrom = value;
    notifyListeners();
  }

  void setSliceTo(int value) {
    sliceTo = value;
    notifyListeners();
  }

  void setFindReplaceEnabled(bool value) {
    findReplaceEnabled = value;
    notifyListeners();
  }

  void setFindText(String text) {
    findText = text;
    notifyListeners();
  }

  void setReplaceText(String text) {
    replaceText = text;
    notifyListeners();
  }

  void setBatchSize(int size) {
    batchSize = size;
    notifyListeners();
  }

  void setLastOutput(PipelineOutput output) {
    lastOutput = output;
    notifyListeners();
  }

  void setIsProcessing(bool value) {
    isProcessing = value;
    notifyListeners();
  }

  void addHistoryRun(PipelineRun run) {
    history.insert(0, run);
    if (history.length > 20) {
      history.removeRange(20, history.length);
    }
    notifyListeners();
  }

  void setHistory(List<PipelineRun> runs) {
    history = runs;
    notifyListeners();
  }

  void restoreHistoryRun(PipelineRun run) {
    final state = run.pipelineState;
    inputText = state['inputText'] ?? '';
    variables = Map<String, String>.from(state['variables'] ?? {});
    splitterEnabled = state['splitterEnabled'] ?? false;
    splitterWordsPerScene = state['splitterWordsPerScene'] ?? 20;
    styleEnabled = state['styleEnabled'] ?? true;
    styleText = state['styleText'] ?? '';
    prefixEnabled = state['prefixEnabled'] ?? false;
    prefixText = state['prefixText'] ?? '/imagine prompt:';
    suffixEnabled = state['suffixEnabled'] ?? false;
    suffixText = state['suffixText'] ?? '--v 6.0 --ar 16:9';
    indexingEnabled = state['indexingEnabled'] ?? false;
    indexingFormat = state['indexingFormat'] ?? '[Scene 01]';
    sliceEnabled = state['sliceEnabled'] ?? false;
    sliceFrom = state['sliceFrom'] ?? 1;
    sliceTo = state['sliceTo'] ?? -1;
    findReplaceEnabled = state['findReplaceEnabled'] ?? false;
    findText = state['findText'] ?? '';
    replaceText = state['replaceText'] ?? '';
    activeStylePreset = state['activeStylePreset'] ?? 'Noir Cinematic';
    notifyListeners();
  }

  void clearHistory() {
    history = [];
    notifyListeners();
  }

  Map<String, dynamic> getPipelineState() {
    return {
      'inputText': inputText,
      'variables': variables,
      'splitterEnabled': splitterEnabled,
      'splitterWordsPerScene': splitterWordsPerScene,
      'styleEnabled': styleEnabled,
      'styleText': styleText,
      'prefixEnabled': prefixEnabled,
      'prefixText': prefixText,
      'suffixEnabled': suffixEnabled,
      'suffixText': suffixText,
      'indexingEnabled': indexingEnabled,
      'indexingFormat': indexingFormat,
      'sliceEnabled': sliceEnabled,
      'sliceFrom': sliceFrom,
      'sliceTo': sliceTo,
      'findReplaceEnabled': findReplaceEnabled,
      'findText': findText,
      'replaceText': replaceText,
      'activeStylePreset': activeStylePreset,
    };
  }

  void resetAll() {
    inputText = '';
    variables = {};
    splitterEnabled = false;
    splitterWordsPerScene = 20;
    styleEnabled = true;
    prefixEnabled = false;
    suffixEnabled = false;
    indexingEnabled = false;
    sliceEnabled = false;
    findReplaceEnabled = false;
    lastOutput = null;
    notifyListeners();
  }
}
