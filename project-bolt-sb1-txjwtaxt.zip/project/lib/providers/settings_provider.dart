import 'package:flutter/material.dart';
import '../models/style_preset.dart';
import '../services/storage_service.dart';

class SettingsProvider extends ChangeNotifier {
  final StorageService storage;
  int defaultBatchSize = 10;
  String defaultStylePreset = 'Noir Cinematic';
  String defaultIndexingFormat = '[Scene 01]';
  List<StylePreset> stylePresets = [];

  SettingsProvider({required this.storage});

  Future<void> init() async {
    defaultBatchSize = await storage.getBatchSize();
    defaultStylePreset = await storage.getActivePreset();
    defaultIndexingFormat = await storage.getIndexingFormat();
    stylePresets = await storage.getStylePresets();
    notifyListeners();
  }

  Future<void> setDefaultBatchSize(int size) async {
    defaultBatchSize = size;
    await storage.setBatchSize(size);
    notifyListeners();
  }

  Future<void> setDefaultStylePreset(String presetName) async {
    defaultStylePreset = presetName;
    await storage.setActivePreset(presetName);
    notifyListeners();
  }

  Future<void> setDefaultIndexingFormat(String format) async {
    defaultIndexingFormat = format;
    await storage.setIndexingFormat(format);
    notifyListeners();
  }

  Future<void> addStylePreset(StylePreset preset) async {
    stylePresets.add(preset);
    await storage.setStylePresets(stylePresets);
    notifyListeners();
  }

  Future<void> updateStylePreset(StylePreset preset) async {
    final index = stylePresets.indexWhere((p) => p.id == preset.id);
    if (index >= 0) {
      stylePresets[index] = preset;
      await storage.setStylePresets(stylePresets);
      notifyListeners();
    }
  }

  Future<void> deleteStylePreset(String presetId) async {
    stylePresets.removeWhere((p) => p.id == presetId);
    await storage.setStylePresets(stylePresets);
    notifyListeners();
  }

  Future<void> reloadStylePresets() async {
    stylePresets = await storage.getStylePresets();
    notifyListeners();
  }

  Future<void> clearAllData() async {
    await storage.clearAll();
    defaultBatchSize = 10;
    defaultStylePreset = 'Noir Cinematic';
    defaultIndexingFormat = '[Scene 01]';
    stylePresets = [StylePreset.defaultPreset()];
    notifyListeners();
  }
}
