import 'package:flutter/material.dart';
import '../models/prompt_item.dart';
import '../services/parser_service.dart';

class EditorProvider extends ChangeNotifier {
  List<PromptItem> prompts = [];
  String detectedFormat = '';
  int totalWords = 0;
  bool selectionMode = false;
  String inputText = '';

  void parseInput(String input, {String? customDelimiter}) {
    final result = ParserService.parse(input, customDelimiter: customDelimiter);
    prompts = result.prompts;
    detectedFormat = result.detectedFormat;
    totalWords = result.totalWords;
    inputText = input;
    selectionMode = false;
    notifyListeners();
  }

  void updatePrompt(int index, String newText) {
    if (index >= 0 && index < prompts.length) {
      prompts[index] = prompts[index].copyWith(text: newText);
      totalWords = prompts.fold<int>(0, (sum, p) => sum + p.wordCount);
      notifyListeners();
    }
  }

  void addPrompt() {
    final newPrompt = PromptItem(text: '', index: prompts.length);
    prompts.add(newPrompt);
    notifyListeners();
  }

  void removePrompt(int index) {
    if (index >= 0 && index < prompts.length) {
      prompts.removeAt(index);
      for (int i = index; i < prompts.length; i++) {
        prompts[i] = prompts[i].copyWith(index: i);
      }
      totalWords = prompts.fold<int>(0, (sum, p) => sum + p.wordCount);
      notifyListeners();
    }
  }

  void reorderPrompts(int oldIndex, int newIndex) {
    if (oldIndex < newIndex) {
      newIndex -= 1;
    }
    final item = prompts.removeAt(oldIndex);
    prompts.insert(newIndex, item);
    for (int i = 0; i < prompts.length; i++) {
      prompts[i] = prompts[i].copyWith(index: i);
    }
    notifyListeners();
  }

  void toggleSelectionMode() {
    selectionMode = !selectionMode;
    if (!selectionMode) {
      for (final prompt in prompts) {
        prompt.isSelected = false;
      }
    }
    notifyListeners();
  }

  void togglePromptSelection(int index) {
    if (index >= 0 && index < prompts.length) {
      prompts[index].isSelected = !prompts[index].isSelected;
      notifyListeners();
    }
  }

  void selectAllPrompts() {
    for (final prompt in prompts) {
      prompt.isSelected = true;
    }
    notifyListeners();
  }

  void deselectAllPrompts() {
    for (final prompt in prompts) {
      prompt.isSelected = false;
    }
    notifyListeners();
  }

  void deleteSelectedPrompts() {
    prompts = prompts.where((p) => !p.isSelected).toList();
    for (int i = 0; i < prompts.length; i++) {
      prompts[i] = prompts[i].copyWith(index: i);
    }
    totalWords = prompts.fold<int>(0, (sum, p) => sum + p.wordCount);
    notifyListeners();
  }

  List<PromptItem> getSelectedPrompts() {
    return prompts.where((p) => p.isSelected).toList();
  }

  String getSelectedAsBlock() {
    final selected = getSelectedPrompts();
    return selected.map((p) => p.text).join('\n\n');
  }

  void clearAll() {
    prompts = [];
    detectedFormat = '';
    totalWords = 0;
    selectionMode = false;
    inputText = '';
    notifyListeners();
  }
}
